The http://support.ktx.com/~200 messages have been compiled by the Developer Consulting Group into 2 separate help files called:

PrivateR2.hlp	
PublicR2.hlp	

These have been placed into 2 zip files called: 

MessageArchive(Public).zip
MessageArchive(Private).zip

Each zip file also contains a table of contents called Archive.cnt. If you are installing both zip files, the Archive.cnt file is identical in both zips. 

Place the complete contents of either or both of these zip files into the same directory as your MAX SDK help file, sdk.hlp. 

Launch either of the 2 help files by double clicking them from the Windows Explorer. 

Notice the new Table of Contents. It has been organized in a fashion similar to the organization of the MAX SDK On-Line Forum found at http://support.ktx.com/~200. 

Each unique thread is completely contained on a single page of the help file. For PrivateR2.hlp and PublicR2.hlp, each reply within the thread is separated by a "_______________________________________________________". 


Additionally, index and find will display search results from *all* of the help files, including the MAX SDK help file,  which makes this search very powerful. 


If you find any errors in these files, please email us with a subject "[367102]Message Archive Comments" to ktx_int@ktx.com. 


Happy Hacking!

Developer Consulting Group
Discreet

