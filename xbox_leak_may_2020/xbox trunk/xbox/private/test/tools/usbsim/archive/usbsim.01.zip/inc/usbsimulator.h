/*****************************************************************************

Copyright (C) 2000-2001 Microsoft Corporation

Module Name:

    USBSimulator.h

Abstract:

    Defines the Simulator control class and the Device base class.

    Library allows for this sort of usage:

        usbsim.FindSimulators();

        XIDDevice *duke = new XIDDevice();
        usbsim.Plug(1, 1, duke);
        Sleep(...)
        duke->SetInputReport(...); // button a down
        Sleep(...)
        duke->SetInputReport(...); // button a up, dpad left
        usbsim.Unplug(duke);
        delete duke;

        BulkDevice *mu = new BulkDevice();
        usbsim.Plug(2, 1, mu);
        Sleep(15000);              // let stuff happen
        usbsim.Unplug(mu);
        delete mu;

Author:

    Josh Poley (jpoley)

Revision History:

*****************************************************************************/

#ifndef _USB_SIMULATOR_H_
#define _USB_SIMULATOR_H_

#ifndef WIN32_LEAN_AND_MEAN
    #define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers
#endif

#include <windows.h>
#include <stdio.h>
#include <winsock2.h>
#include <crtdbg.h>

#include "CWorkerThread.h"
#include "SimPacket.h"


//
// Error Codes
//
#define USBSIM_ERROR_OK                 0  // A-OK
#define USBSIM_ERROR_CONNECTED          1  // Device is already connected
#define USBSIM_ERROR_NOTCONNECTED       2  // Device is not connected
#define USBSIM_ERROR_CONNECT_FAILED     3  // Use WSAGetLastError to get more information
#define USBSIM_ERROR_SOCKET_ERROR       4  // Use WSAGetLastError to get more information
#define USBSIM_ERROR_INVALID_USB_PORT   5  // Parameter is out of range or denotes a port currently not in use
#define USBSIM_ERROR_INVALID_SIMULATOR  6  // Parameter is out of range or denotes a port currently not in use
#define USBSIM_ERROR_INVALID_DEVICE     7  // Pointer to a USBDevice is not valid
#define USBSIM_ERROR_USER_ABORT         8  // Abort specifed by the user
#define USBSIM_ERROR_TIMEOUT            9  // Timeout waiting for response from simulator
#define USBSIM_ERROR_DATA_CORRUPTED    10  // Got data from the simulator but it is likely corrupted


//
// Magic Numbers
//
#define USBSIM_MAX_SIMULATORS           4   // # ports on an xbox
#define USBSIM_MAX_USBPORTS             4   // # usb devices on a simulator
#define USBSIM_RECV_RETRYS              4   // # of times network code will retry an operation


//
// Port values used in USBSimulator::Plug
//
#define USBSIM_HOST_PORT1               1
#define USBSIM_HOST_PORT2               2
#define USBSIM_HOST_PORT3               3
#define USBSIM_HOST_PORT4               4



//
// USB PID values (USB Spec section 8.3.1 table 8-1)
//
#define USB_PID_OUT         0x87
#define USB_PID_IN          0x96
#define USB_PID_SOF         0xA5
#define USB_PID_SETUP       0xB4
#define USB_PID_DATA0       0xC3
#define USB_PID_DATA1       0xD2
#define USB_PID_DATA2       0xE1
#define USB_PID_MDATA       0xF0
#define USB_PID_ACK         0x4B
#define USB_PID_NAK         0x5A
#define USB_PID_STALL       0x78
#define USB_PID_NYET        0x69
#define USB_PID_PRE         0x3C
#define USB_PID_ERR         USB_PID_PRE
#define USB_PID_SPLIT       0x1E
#define USB_PID_PING        0x2D
#define USB_PID_RESERVED    0x0F



class USBDevice;

/*****************************************************************************

Class Description:

    USBSimulator

    This object manages information on remote simulators, and allows a device
    class to attach to a given simulator.

Notes:
    

*****************************************************************************/
class USBSimulator
    {
    private:
        DWORD ip[USBSIM_MAX_SIMULATORS]; // == to S_addr in the in_addr struct

    public:
        bool record;        // used to initialize a device's record flag 
                            // when its Pluged in

    public:
        USBSimulator();
        ~USBSimulator();

    public:
        DWORD FindSimulators(void);
        DWORD GetActivePorts(char simulator);
        // TODO DWORD GetMACAddress(char simulator);

    public:
        DWORD Plug(int port, char simulator, USBDevice *vdevice);
        DWORD Unplug(USBDevice *vdevice);
    };



/*****************************************************************************

Class Description:

    USBDevice

    This class defines the core functionality for every "device". All devices
    are children of this object.

Notes:
    

*****************************************************************************/
class USBDevice : public CWorkerThread
    {
    private:
        DWORD simIP;            // simulator IP address
        char usbPort;           // port we are on
        bool record;            // true to log all TCP traffic

    protected:
        SOCKET sock;
        char *receiveBuffer;    // buffer which receives incomming data
        unsigned bufferSize;    // max size of above buffer

    protected:
        int IsDataAvailable(void);
        DWORD GetPacket(void);
        DWORD WaitForUSBPacket(int command, int subcommand, int pid);
        DWORD SetupEndpoint(unsigned endpoint, unsigned type, unsigned fifoSize, unsigned autoRepeat);
        int recv(SOCKET s, char *buf, int len, int flags);
        int send(SOCKET s, char *buf, int len, int flags);

    public:
        USBDevice();
        virtual ~USBDevice();

    // virtual member functions
    public:
        DWORD ThreadFunct(void);
        virtual DWORD Initialize(void) = 0;
        virtual DWORD Receive(void) = 0;
        virtual char* GetName(void) = 0;
        virtual bool IsEnumerated(void) = 0;

    public:
        void LogPacket(char *data, int len, bool outGoing);
        void USBDevice::LogPrint(char* format, ...);

        friend class USBSimulator; // give the USBSimulator access to us
    };

//
// Debug output printing functions
//
void _DebugPrint(char* lpszFormat, ...);
void PrintPacket(SimPacket *packet);

//
// All defined child devices will go here:
//
#include "XIDDevice.h"

#endif // _USB_SIMULATOR_H_
