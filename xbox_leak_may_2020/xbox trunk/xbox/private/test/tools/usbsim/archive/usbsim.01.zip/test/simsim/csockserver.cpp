// CSockServer.cpp
//
// This class will allow the creation of the Winsock Server object that
// can send and receive data within it's own thread.
//
// It is derived from a Thread class created from Josh Poley
//
// CSockServer is a modification of a class created by Jim Helm
///////////////////////////////////////////////////////////////////////
#include "CSockServer.h"

#include "..\..\inc\SimPacket.h"
void HandleDukeStuff(SOCKET sock);
#include <stdio.h>

// Bind or Name our socket
int CSockServer::BindSocket()
    {
    int nReturnVal=0;						// Return Value for BindSocket()

    m_sockaddr.sin_family = AF_INET;
    m_sockaddr.sin_port = htons(GetPort());
    m_sockaddr.sin_addr.s_addr = htonl(INADDR_ANY); // (u_long)0x9D370D57

    nReturnVal = bind(m_socket, (LPSOCKADDR)&m_sockaddr, sizeof(SOCKADDR));
    if(SOCKET_ERROR == nReturnVal)
        {
        //nReturnVal = GetLastError();
        //Trace("Bind failed!\n");
        //Trace("WS Last Error : %d\n", GetLastWSError());
        printf("Bind failed!\n");
        }

    return (nReturnVal);
    }


// Close our Socket
int CSockServer::CloseSocket(SOCKET s)
    {
    int nReturnVal=0;		// Return Value of CloseSocket()

    Lock();
    if(NULL == s)
        {
        s = m_socket;
        }

    // Shutdown the socket (will fail if not connected)
    nReturnVal = shutdown(s, SD_BOTH);
    if(SOCKET_ERROR == nReturnVal)
        {
        //nReturnVal = GetLastError();
        //Trace("Shutdown(s) failed!\n");
        //Trace("WS Last Error : %s\n", GetLastWSError());
        }

    // Close the socket
    nReturnVal = closesocket(s);
    if(SOCKET_ERROR == nReturnVal)
        {
        //nReturnVal = GetLastError();
        //Trace("closesocket(s) failed!\n");
        //Trace("WS Last Error : %s\n", GetLastWSError());
        }
    Unlock();

    return (nReturnVal);
    }

// Constructor
CSockServer::CSockServer()
    {
    parent = NULL;
    m_socket = NULL;
    m_remotesocket = NULL;
    m_socktype = SOCK_STREAM;
    m_key[0] = '\0';
    }

// Destructor
CSockServer::~CSockServer()
    {
    CloseSocket(m_socket);
    }


SOCKET CSockServer::GetRemoteSocket()
    {
    SOCKET s;		// Temp socket to hold our accepted socket

    Lock();
    s = m_remotesocket;
    m_remotesocket = NULL;
    Unlock();

    return (s);
    }

// Get our Socket
int CSockServer::GetSocket(int af, int socktype, int protocol)
    {
    int nReturnVal=0;		// Return value for GetSocket()

    m_socket = socket(af, socktype, protocol);
    if(INVALID_SOCKET == m_socket)
        {
        //nReturnVal=WSAGetLastError();
        printf("socket failed: Last WS Error: %u\n", WSAGetLastError ());
        }

    return nReturnVal;
    }

// Initialize our Windows Socket
// Returns 0 if successful, non-zero if there was a problem
int CSockServer::Init(WORD wVersionRequested)
    {
    int nReturnVal=0;			// Return value of Init()

    nReturnVal = WSAStartup(wVersionRequested, &m_wsadata);

    return nReturnVal;
    }

// Create our server socket
int CSockServer::OpenServerSocket(int socktype)
    {
    int nReturnVal;			// Return value for OpenServerSocket()
    if(socktype == SOCK_DGRAM) nReturnVal = GetSocket(AF_INET, socktype, 0);
    else nReturnVal = GetSocket(AF_INET, socktype, IPPROTO_TCP);
    if(WSANOTINITIALISED == nReturnVal)
        {
        if(0 == Init())
            {
            nReturnVal = GetSocket();
            }
        }
    return nReturnVal;
    }

BOOL CSockServer::IsDataAvailable(SOCKET s)
    {
    TIMEVAL timeout;
    FD_SET bucket;
    bucket.fd_count = 1;
    bucket.fd_array[0] = s;
    timeout.tv_sec = 60;
    timeout.tv_usec = 0;

    int err = select(0, &bucket, NULL, NULL, &timeout);
    if(err == 0 || err == SOCKET_ERROR)
        {
        return FALSE;
        }

    return TRUE;
    }


// Thread code for our Winsock Server
DWORD CSockServer::ThreadFunct(void)
    {
	DWORD nReturnVal=0;				// Return Value of ThreadFunct()

	while(!GetExitFlag())
        {
        if(m_socktype == SOCK_STREAM)
            {
            if(SOCKET_ERROR == listen(m_socket, 1))
                {
                printf("listen error: %d\n", WSAGetLastError());
                break;
                }
            else
                {
                m_remotesocket = accept(m_socket, NULL, NULL);
                if(INVALID_SOCKET == m_remotesocket)
                    {
                    printf("accept error: %d\n", WSAGetLastError());
                    continue;
                    }
                else
                    {
                    HandleDukeStuff(m_remotesocket);
                    }
                }
            }
        else // socktype == SOCK_DGRAM (broadcast monitor)
            {
            char buffer[1024];
            SimPacket *packet = (SimPacket*)buffer;
            int err;
            SOCKADDR_IN dest;
            int addrsize=sizeof(SOCKADDR);
            TIMEVAL timeout;
            FD_SET bucket;
            bucket.fd_count = 1;
            bucket.fd_array[0] = m_socket;
            timeout.tv_sec = 5;
            timeout.tv_usec = 0;

            err = select(0, &bucket, NULL, NULL, &timeout);
            if(err == 0 || err == SOCKET_ERROR) continue;

            err = recvfrom(m_socket, buffer, 1024, 0, (SOCKADDR*)&dest, &addrsize);
            if(err>0)
                {
                buffer[err] = '\0';
                }
            else
                {
                Sleep(10);
                continue;
                }

            printf("Received BroadCast, sending IPQuery\n");
            if(packet->command == SIM_CMD_IPQUERY)
                {
                packet->subcommand = 0;
                packet->dataSize = 4;
                packet->data[0] = 1;
                packet->data[1] = 2;
                packet->data[2] = 3;
                packet->data[3] = 4;
                sendto(m_socket, buffer, packet->dataSize+sizeof(SimPacketHeader), 0, (SOCKADDR*)&dest, sizeof(SOCKADDR));
                }
            else
                {
                printf(" The command on the broadcast was not IPQUERY\n");
                }
            }
        }

    return nReturnVal;
    }