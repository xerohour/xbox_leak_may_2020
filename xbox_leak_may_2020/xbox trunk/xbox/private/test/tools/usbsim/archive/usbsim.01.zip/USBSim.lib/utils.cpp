/*****************************************************************************

Copyright (C) 2000-2001 Microsoft Corporation

Module Name:

    Utils.cpp

Abstract:

    

Author:

    Josh Poley (jpoley)

Revision History:

*****************************************************************************/

#include "..\inc\USBSimulator.h"

void _DebugPrint(char* lpszFormat, ...)
    {
    va_list args;
    va_start(args, lpszFormat);

    char szBuffer[1024];

    vsprintf(szBuffer, lpszFormat, args);
    OutputDebugStringA(szBuffer);

    va_end(args);
    }

void PrintPacket(SimPacket *packet)
    {
    _DebugPrint("SimPacket:\n  command:    %d\n  subcommand: %d\n  datasize:   %d\n  data:       ", packet->command, packet->subcommand, packet->dataSize);
    for(unsigned i=0; i<packet->dataSize; i++)
        _DebugPrint("%02X ", packet->data[i]);
    _DebugPrint("\n");
    }

