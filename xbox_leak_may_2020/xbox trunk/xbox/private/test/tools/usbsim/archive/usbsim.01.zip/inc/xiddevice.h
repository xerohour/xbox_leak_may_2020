/*****************************************************************************

Copyright (C) 2000-2001 Microsoft Corporation

Module Name:

    XIDDevice.h

Abstract:


Author:

    Josh Poley (jpoley)

Revision History:

*****************************************************************************/

#ifndef _XIDDEVICE_H_
#define _XIDDEVICE_H_

#pragma pack(push, 1) // align structure members on a byte boundry
struct XIDInputReport
    {
    unsigned __int8  reportID;
    unsigned __int8  size;
    unsigned __int16 buttons;
    unsigned __int8  analogButtons[8];
    unsigned __int16 thumbLX;
    unsigned __int16 thumbLY;
    unsigned __int16 thumbRX;
    unsigned __int16 thumbRY;
    };
extern XIDInputReport defaultXIDReport;
#pragma pack(pop)

#define USB_XID_PACKETSIZE      sizeof(XIDInputReport)


/*****************************************************************************

Class Description:


Methods:



Data:



Notes:
    

*****************************************************************************/
class XIDDevice : public USBDevice
    {
    public:
        unsigned enumerateState[10];
        int data01;

    protected:
        char xidPacket[USB_XID_PACKETSIZE];

    public:
        XIDDevice();
        ~XIDDevice();

    // virtual member functions
    public:
        DWORD Initialize(void);
        DWORD Send(unsigned size, char*dataBuffer);
        DWORD Receive(void);
        char* GetName(void);
        bool IsEnumerated(void);

    public:
        DWORD SetInputReport(XIDInputReport *xid);
        DWORD SetInputReport(unsigned __int8  reportID, unsigned __int8  size, unsigned __int16 buttons, unsigned __int8 *analogButtons, unsigned __int16 thumbLX, unsigned __int16 thumbLY, unsigned __int16 thumbRX, unsigned __int16 thumbRY);
    };

#endif // _XIDDEVICE_H_
