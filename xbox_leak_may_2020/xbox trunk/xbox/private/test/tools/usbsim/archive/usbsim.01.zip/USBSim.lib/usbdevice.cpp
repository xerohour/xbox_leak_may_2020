/*****************************************************************************

Copyright (C) 2000-2001 Microsoft Corporation

Module Name:

    USBDevice.cpp

Abstract:

    This class defines the core functionality for every "device". All devices
    are children of this object.

    Defined in "USBSimulator.h"

Author:

    Josh Poley (jpoley)

Revision History:

*****************************************************************************/

#include "..\inc\USBSimulator.h"
#include <malloc.h>


/*****************************************************************************

Routine Description:

    Default Constructor/Destructor

Arguments:

    none

Return Value:

    none

*****************************************************************************/
USBDevice::USBDevice()
    {
    simIP = 0;
    usbPort = 0;
    sock = INVALID_SOCKET;
    record = false;
    receiveBuffer = 0;
    bufferSize = 0;
    }

USBDevice::~USBDevice()
    {
    // make sure the user USBSimulator.Unplug()s the device before destroying it
    _ASSERT(sock == INVALID_SOCKET);
    }


/*****************************************************************************

Routine Description:

    LogPacket

    Takes a network packet, formats it and writes it to the log. Only writes 
    to the log if this->record == true.

Arguments:
    
    char *data      [in] pointer to the network packet
    int len         [in] size of the packet
    bool outGoing   [in] true for send, or false for recv

Return Value:

    none
    
*****************************************************************************/
void USBDevice::LogPacket(char *data, int len, bool outGoing)
    {
    if(!record) return;

    SimPacket *packet = (SimPacket*)data;
    char *buffer = (char*)_alloca(len*4 + 128);
    char *ptr = buffer;

    ptr += sprintf(ptr, "%08X %s:\n    %d, %d, %d, %d", this, (outGoing==1?"ToSimulator":"FromSimulator"), packet->command, packet->subcommand, packet->param, packet->dataSize);
    if(packet->dataSize) ptr += sprintf(ptr, "\n   ");
    for(unsigned i=0; i<packet->dataSize; i++)
        ptr += sprintf(ptr, " %02X", packet->data[i]);

    FILE *f = fopen("usbsim.log", "a+");
    fprintf(f, "%s\n", buffer);
    fclose(f);
    }


/*****************************************************************************

Routine Description:

    LogPrint

    Writes a formatted string (like printf) to the log. Only writes to the 
    log if this->record == true.

Arguments:

    char* format    [in] format specifier
    ...             [in] arguments to the format

Return Value:

    none
    
*****************************************************************************/
void USBDevice::LogPrint(char* format, ...)
    {
    if(!record) return;

    va_list args;
    va_start(args, format);

    char buffer[1024];

    vsprintf(buffer, format, args);

    FILE *f = fopen("usbsim.log", "a+");
    fprintf(f, "%08X %s\n", this, buffer);
    fclose(f);

    va_end(args);
    }


/*****************************************************************************

Routine Description:

    recv

    Override Winsock's recv to include logging

Arguments:

    see documentation on 'recv' 

Return Value:

    see documentation on 'recv' 
    
*****************************************************************************/
int USBDevice::recv(SOCKET s, char *buf, int len, int flags)
    {
    int ret = ::recv(s, buf, len, flags);

    if(flags & MSG_PEEK) return ret;

    LogPacket(buf, len, false);

    return ret;
    }


/*****************************************************************************

Routine Description:

    send

    Override Winsock's send to include logging

Arguments:

    see documentation on 'send' 

Return Value:

    see documentation on 'send' 
    
*****************************************************************************/
int USBDevice::send(SOCKET s, char *buf, int len, int flags)
    {
    int ret = ::send(s, buf, len, flags);

    LogPacket(buf, len, true);

    return ret;
    }


/*****************************************************************************

Routine Description:

    IsDataAvailable

    Checks to see if there is new data in the receive buffer

Arguments:

    none

Return Value:

    0 or SOCKET_ERROR - no data is available
    1 - data is available to recv
    
*****************************************************************************/
int USBDevice::IsDataAvailable(void)
    {
    TIMEVAL timeout;
    FD_SET bucket;

    timeout.tv_sec = 0;
    timeout.tv_usec = 250000;
    bucket.fd_count = 1;
    bucket.fd_array[0] = sock;

    return select(0, &bucket, NULL, NULL, &timeout);
    }


/*****************************************************************************

Routine Description:

    GetPacket

    Looks for a new data in the receive buffer, and reads just enough for 1
    packet.

Arguments:

    none

Return Value:

    DWORD   USBSIM error code (see "USBSimulator.h")

Notes:

    If the packet is a usb packet (SIM_CMD_USBDATA) AND its an IN packet, then
    we HAVE to look at the next packet. If the next packet is an ACK then the
    application has already responded to the IN and we DO NOT return it (but
    we do return the ACK). Otherwise (next packet was a NAK) we return the IN 
    and leave the NAK in the receive buffer.

*****************************************************************************/
DWORD USBDevice::GetPacket(void)
    {
    SimPacket *packet = (SimPacket*)receiveBuffer;
    int err = 0;

    for(unsigned i=0; i<USBSIM_RECV_RETRYS; i++)
        {
        if(GetExitFlag()) return USBSIM_ERROR_USER_ABORT;
        if(IsDataAvailable() == 1)
            {
            // look at the packet header
            err = recv(sock, (char*)packet, sizeof(SimPacketHeader), MSG_PEEK);
            if(err == 0 || err == SOCKET_ERROR) return USBSIM_ERROR_SOCKET_ERROR;
            
            // assert if our receiveBuffer is not big enough!
            _ASSERT(packet->dataSize+sizeof(SimPacketHeader) < bufferSize);

            // read the packet header & data
            err = recv(sock, (char*)packet, sizeof(SimPacketHeader)+packet->dataSize, 0);
            if(err == 0 || err == SOCKET_ERROR) return USBSIM_ERROR_SOCKET_ERROR;

            #ifdef _DEBUG
            PrintPacket(packet);
            #endif

            // If we get an IN, we need to determin if we have to deal with it or
            // if its already been handled. To do this, we look at the next packet.
            if(packet->command == SIM_CMD_USBDATA && packet->data[0] == USB_PID_IN)
                {
                SimPacket *packet2 = (SimPacket*)(receiveBuffer+sizeof(SimPacketHeader)+packet->dataSize);
                err = recv(sock, (char*)packet2, sizeof(SimPacketHeader)+1, MSG_PEEK);
                if(!(err == 0 || err == SOCKET_ERROR))
                    {
                    if(packet2->command == SIM_CMD_USBEXTRADATA && packet2->data[1] == USB_PID_ACK)
                        {
                        // eat the IN (its just info - no need to respond to it), return the ack
                        err = recv(sock, (char*)packet, sizeof(SimPacketHeader)+packet2->dataSize, 0);
                        if(err == 0 || err == SOCKET_ERROR) return USBSIM_ERROR_SOCKET_ERROR;
                        }
                    }
                // otherwise, IN not followed by an ACK, return the IN
                }

            return USBSIM_ERROR_OK;
            }
        }

    return USBSIM_ERROR_TIMEOUT;
    }


/*****************************************************************************

Routine Description:

    WaitForUSBPacket

    Calls GetPacket(), if the returned packet meets the specified requirements 
    we will return that packet, otherwise we will wait around for it.

Arguments:

    int command     [in] packet type (-1 for ignore this filter)
    int subcommand  [in] packet sub type (-1 for ignore this filter)
    int pid         [in] specific value for data[0] (-1 for ignore this filter)

Return Value:

    DWORD   USBSIM error code (see "USBSimulator.h")

*****************************************************************************/
DWORD USBDevice::WaitForUSBPacket(int command, int subcommand, int pid)
    {
    DWORD err = 0;
    SimPacket *packet = (SimPacket*)receiveBuffer;
    USBPacket *usb = (USBPacket*)packet->data;

    for(int i=0; i<USBSIM_RECV_RETRYS; i++)
        {
        err = GetPacket();
        if(err != USBSIM_ERROR_OK) continue;

        if(command != -1) if(packet->command != command) continue;
        if(subcommand != -1) if(packet->subcommand != subcommand) continue;
        if(pid != -1) if(usb->pid != pid) continue;
        return USBSIM_ERROR_OK;
        }

    return USBSIM_ERROR_TIMEOUT;
    }


/*****************************************************************************

Routine Description:

    SetupEndpoint

    Sends a SIM_SUBCMD_SETUP_ENDPOINT packet with the specified settings for
    a given endpoint number.

Arguments:

    unsigned endpoint   [in] 0-7 specifies which endpoint we are setting
    unsigned type       [in] the type (see enum _SIM_ENDPOINT_SETUP_TYPES)
    unsigned fifoSize   [in] the size (see enum _SIM_ENDPOINT_SETUP_SIZE)
    unsigned autoRepeat [in] auto repeat (see _SIM_ENDPOINT_SETUP_AUTO_REPEAT)

Return Value:

    DWORD   USBSIM error code (see "USBSimulator.h")

Notes:

    The enum definitions are in "SimPacket.h"

    See document "621F01" for descriptions of the endpoint settings

*****************************************************************************/
DWORD USBDevice::SetupEndpoint(unsigned endpoint, unsigned type, unsigned fifoSize, unsigned autoRepeat)
    {
    if(sock == INVALID_SOCKET) return USBSIM_ERROR_NOTCONNECTED;

    SimPacketWithSetupEndpoint setup;

    setup.header.command = SIM_CMD_SETUP;
    setup.header.subcommand = SIM_SUBCMD_SETUP_ENDPOINT;
    setup.header.param = (unsigned __int8)endpoint;
    setup.header.dataSize = sizeof(EndpointSetup);
    setup.endpoint.fifoSize = (unsigned __int8)fifoSize;
    setup.endpoint.type = (unsigned __int8)type;
    setup.endpoint.autoRepeat = (unsigned __int8)autoRepeat;
    send(sock, (char*)&setup, sizeof(SimPacketWithSetupEndpoint), 0);

    return USBSIM_ERROR_OK;
    }


/*****************************************************************************

Routine Description:

    ThreadFunct

    The is the worker thread function for every device. The thread will exit 
    when this function returns.

Arguments:

    none

Return Value:

    DWORD   USBSIM error code (see "USBSimulator.h")

Notes:

    See CWorkerThread.h & CWorkerThread.cpp for more information on this
    member function.

*****************************************************************************/
DWORD USBDevice::ThreadFunct(void)
    {
    DWORD error = 0;

    while(! GetExitFlag())
        {
        // check for available data
        error = GetPacket();
        if(error == USBSIM_ERROR_TIMEOUT) continue;
        else if(error != USBSIM_ERROR_OK) break;

        // check again for exit notification
        if(GetExitFlag()) break;

        // Process the data
        Receive();
        }

    return error;
    }
