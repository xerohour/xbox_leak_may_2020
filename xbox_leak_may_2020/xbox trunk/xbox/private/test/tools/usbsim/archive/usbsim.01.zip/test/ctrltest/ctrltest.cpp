/*****************************************************************************

Copyright (C) 2000-2001 Microsoft Corporation

Module Name:

    ctrltest.cpp

Abstract:

    

Author:

    Josh Poley (jpoley)

Revision History:

*****************************************************************************/

#include "..\..\inc\USBSimulator.h"
#include <stdio.h>


int main(int argc, char* argv[])
    {
    USBSimulator usbsim;
    usbsim.record = true; // enable logging to usbsim.log

    printf("Starting Test\n");

    unsigned numSimulators = usbsim.FindSimulators();
    printf("Found %u simulators\n", numSimulators);
    if(numSimulators == 0)
        {
        printf("Startup 1 or more USB Simulators on the network first!\n");
        printf("Press Enter...");
        getchar();
        return 0;
        }

    //
    // Duke Test
    //
    printf("Running Duke Test\n");
    XIDDevice *xid = new XIDDevice;

    printf("   Inserting the device\n");
    usbsim.Plug(USBSIM_HOST_PORT1, 0, xid);

    printf("   Waiting for 5 seconds...\n");
    Sleep(1000); // let stuff happen

    xid->IsEnumerated();
    Sleep(4000);

    printf("   Removing the device\n");
    usbsim.Unplug(xid);
    delete xid;

    printf("Press Enter...");
    getchar();
    return 0;
    }

