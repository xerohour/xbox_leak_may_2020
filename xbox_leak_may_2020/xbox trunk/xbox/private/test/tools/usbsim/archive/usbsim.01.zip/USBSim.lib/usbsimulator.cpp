/*****************************************************************************

Copyright (C) 2000-2001 Microsoft Corporation

Module Name:

    USBSimulator.cpp

Abstract:

    This object manages information on remote simulators, and allows a device
    class to attach to a given simulator.

Author:

    Josh Poley (jpoley)

Revision History:

*****************************************************************************/

#include "..\inc\USBSimulator.h"


/*****************************************************************************

Routine Description:

    Default Constructor/Destructor

Arguments:

    none

Return Value:

    none

*****************************************************************************/
USBSimulator::USBSimulator()
    {
    WSADATA wsaData;
    unsigned short version = MAKEWORD(2, 2);
    WSAStartup(version, &wsaData);

    for(size_t i=0; i<USBSIM_MAX_SIMULATORS; i++)
        {
        ip[i] = 0;
        }
    record = false;
    }

USBSimulator::~USBSimulator()
    {
    WSACleanup();
    }


/*****************************************************************************

Routine Description:
    
    FindSimulators

    Creates a list of IP Addresses for simulator devices that are connected
    through the network.

Arguments:

    none

Return Value:

    DWORD - the number of simulators that responded to the query

Notes:


*****************************************************************************/
DWORD USBSimulator::FindSimulators(void)
    {
    DWORD count=0;
    SOCKET sock=0;
    int err=0;
    BOOL val=TRUE;
    SOCKADDR_IN dest;
    int addrsize=sizeof(SOCKADDR);
    char buffer[1024];
    SimPacketHeader ipQuery = { SIM_CMD_IPQUERY, 0, 0, 0 };
    SimPacket *response = (SimPacket*)buffer;

    // broadcast ip query
    sock = socket(AF_INET, SOCK_DGRAM, 0);
    err = setsockopt(sock, SOL_SOCKET, SO_BROADCAST, (char*)&val, sizeof(BOOL));
    dest.sin_family = AF_INET;
    dest.sin_port = htons(0);
    dest.sin_addr.s_addr = htonl(INADDR_ANY);
    err = bind(sock, (SOCKADDR *)&dest, sizeof(SOCKADDR_IN));
    if(err == SOCKET_ERROR)
        {
        return 0;
        }
    dest.sin_port = htons(SIM_NETPORT_IPQUERY);
    dest.sin_addr.s_addr = htonl(INADDR_BROADCAST);
    err = sendto(sock, (char*)&ipQuery, sizeof(SimPacketHeader), 0, (SOCKADDR*)&dest, addrsize);
    if(err == SOCKET_ERROR)
        {
        return 0;
        }

    TIMEVAL timeout;
    FD_SET bucket;
    bucket.fd_count = 1;
    bucket.fd_array[0] = sock;
    timeout.tv_sec = 1;
    timeout.tv_usec = 0;

    for(unsigned i=0; i<USBSIM_MAX_SIMULATORS; i++)
        {
        // wait for responses
        err = select(0, &bucket, NULL, NULL, &timeout);
        if(err == 0 || err == SOCKET_ERROR) break; // we hit timeout so bail

        // grab the response
        err = recvfrom(sock, buffer, 1024, 0, (SOCKADDR*)&dest, &addrsize);
        if(err == 0) break; // no more data

        _DebugPrint("Found Client [%s]:\n", inet_ntoa(dest.sin_addr));
        PrintPacket(response);

        if(response->command != SIM_CMD_IPQUERY)
            {
            // error
            }
        else
            {
            ip[count] = dest.sin_addr.S_un.S_addr;
            ++count;
            }
        }

    // null out the unused spots
    for(i=count; i<USBSIM_MAX_SIMULATORS; i++)
        {
        ip[i] = 0;
        }

    // clean up
    closesocket(sock);

    return count;
    }


/*****************************************************************************

Routine Description:

    GetActivePorts

    Queries a given simulator for its active ports 
    (SIM_SUBCMD_STATUS_CONNECTED)

Arguments:

    char simulator      [in] zero based index of the simulator to query

Return Value:

    DWORD - bitmask representing which USB "devices" are currently active

Notes:


*****************************************************************************/
#pragma warning(push)
#pragma warning(disable : 4127) // no warning on while(0)
DWORD USBSimulator::GetActivePorts(char simulator)
    {
    SOCKADDR_IN dest;
    SOCKET sock;
    char buffer[1024];
    SimPacketHeader portQuery = { SIM_CMD_STATUS, SIM_SUBCMD_STATUS_CONNECTED, 0, 0 };
    SimPacket *response = (SimPacket*)buffer;
    DWORD mask = 0;

    if(simulator > USBSIM_MAX_SIMULATORS || simulator < 0 || ip[simulator] == 0) return USBSIM_ERROR_INVALID_SIMULATOR;

    // connect to the simulator
    dest.sin_port = htons(SIM_NETPORT_BASE);
    dest.sin_addr.s_addr = ip[simulator];
    sock = socket(PF_INET, SOCK_STREAM, 0);

    if(sock == INVALID_SOCKET) return 0;
    if(connect(sock, (SOCKADDR*)&dest, sizeof(SOCKADDR)) == SOCKET_ERROR) return 0;

    do  {
        if(send(sock, (char*)&portQuery, sizeof(SimPacketHeader), 0) == 0) break;

        // wait for the response
        TIMEVAL timeout;
        FD_SET bucket;
        bucket.fd_count = 1;
        bucket.fd_array[0] = sock;
        timeout.tv_sec = 1;
        timeout.tv_usec = 0;
        int err = select(0, &bucket, NULL, NULL, &timeout);
        if(err == 0 || err == SOCKET_ERROR) break; // no response

        // got a response
        if(recv(sock, buffer, 1024, 0) == 0) break;

        mask = response->data[0];
        } while(0);

    // close the connection
    shutdown(sock, SD_BOTH);
    closesocket(sock);

    return mask;
    }
#pragma warning(pop)


/*****************************************************************************

Routine Description:

    Plug

    Inserts a new device into a "port" on a simulator. Internally we connect
    to the simulator on the proper TCP port, then initialize the device and
    start it's worker thread.

Arguments:

    int port            [in] 1-4
    char simulator      [in] 0 based index of which simulator to attach to
    USBDevice *vdevice  [in] pointer to a new USBDevice class (or child)

Return Value:

    DWORD   USBSIM error code (see "USBSimulator.h")

Notes:

    The device must not be currently attached to any other simulator!

*****************************************************************************/
DWORD USBSimulator::Plug(int port, char simulator, USBDevice *vdevice)
    {
    if(!vdevice) return USBSIM_ERROR_INVALID_DEVICE;
    if(vdevice->sock != INVALID_SOCKET) return USBSIM_ERROR_CONNECTED;

    if(simulator > USBSIM_MAX_SIMULATORS || simulator < 0 || ip[simulator] == 0) return USBSIM_ERROR_INVALID_SIMULATOR;
    if(port < 0 || port > USBSIM_MAX_USBPORTS) return USBSIM_ERROR_INVALID_USB_PORT;

    // TODO if -1 find open port/sim
    port += SIM_NETPORT_BASE;

    // connect to the simulator
    SOCKADDR_IN dest;
    dest.sin_family = PF_INET;
    dest.sin_port = htons((unsigned short)port);
    dest.sin_addr.s_addr = ip[simulator];
    vdevice->sock = socket(PF_INET, SOCK_STREAM, 0);
    if(vdevice->sock == INVALID_SOCKET) return USBSIM_ERROR_CONNECT_FAILED;
    if(connect(vdevice->sock, (SOCKADDR*)&dest, sizeof(SOCKADDR)) == SOCKET_ERROR) return USBSIM_ERROR_CONNECT_FAILED;

    // initialize settings in the device
    vdevice->record = record;
    vdevice->usbPort = (char)(port-SIM_NETPORT_BASE);
    vdevice->simIP = ip[simulator];
    vdevice->LogPrint("Inserted device (%s) on port %d of simulator %u.%u.%u.%u", vdevice->GetName(), vdevice->usbPort, ((unsigned char*)&vdevice->simIP)[0], ((unsigned char*)&vdevice->simIP)[1], ((unsigned char*)&vdevice->simIP)[2], ((unsigned char*)&vdevice->simIP)[3]);

    // Start the USB Thread that listens for commands and responds to them
    vdevice->Initialize();
    vdevice->Run();

    return USBSIM_ERROR_OK;
    }


/*****************************************************************************

Routine Description:

    Unplug

    This removes the device from the simulator by closing the TCP connection
    and then signals the device's worker thread to exit.

Arguments:

    USBDevice *vdevice  [in] pointer to a device plugged in using Plug()

Return Value:

    DWORD   USBSIM error code (see "USBSimulator.h")

*****************************************************************************/
DWORD USBSimulator::Unplug(USBDevice *vdevice)
    {
    if(!vdevice) return USBSIM_ERROR_INVALID_DEVICE;
    if(vdevice->sock == INVALID_SOCKET) return USBSIM_ERROR_NOTCONNECTED;

    // tell the thread to shut down
    vdevice->SoftBreak(0);

    // close socket
    shutdown(vdevice->sock, SD_BOTH);
    closesocket(vdevice->sock);
    vdevice->sock = INVALID_SOCKET;

    // make sure the thread stopped, and wait for it if it hasn't
    DWORD timeout = 500;
    while(vdevice->SoftBreak(timeout) != TRUE)
        {
        timeout *= 2;

        if(timeout == 32000)
            {
            // the thread did not respond for ~30 seconds
            // so do the evil and terminate it
            vdevice->HardBreak();
            }
        }

    vdevice->LogPrint("Removed device (%s) from port %d of simulator %u.%u.%u.%u", vdevice->GetName(), vdevice->usbPort, ((unsigned char*)&vdevice->simIP)[0], ((unsigned char*)&vdevice->simIP)[1], ((unsigned char*)&vdevice->simIP)[2], ((unsigned char*)&vdevice->simIP)[3]);

    return USBSIM_ERROR_OK;
    }



