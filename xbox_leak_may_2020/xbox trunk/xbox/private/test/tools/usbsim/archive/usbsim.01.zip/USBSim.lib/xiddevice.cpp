/*****************************************************************************

Copyright (C) 2000-2001 Microsoft Corporation

Module Name:

    XIDDevice.cpp

Abstract:

    

Author:

    Josh Poley (jpoley)

Revision History:

*****************************************************************************/

#include "..\inc\USBSimulator.h"

char *DeviceName = "XID Device";
XIDInputReport defaultXIDReport = { 0, sizeof(XIDInputReport), 0, {0, 0, 0, 0, 0, 0, 0, 0}, 0, 0, 0, 0 };

/*****************************************************************************

Routine Description:

    Default Constructor/Destructor

Arguments:

    none

Return Value:

    none

*****************************************************************************/
XIDDevice::XIDDevice()
    {
    data01 = 1;
    for(unsigned i=0; i<10; i++)
        enumerateState[i] = 0;
    bufferSize = 1024;
    receiveBuffer = new char[bufferSize];
    memcpy(xidPacket, &defaultXIDReport, USB_XID_PACKETSIZE);
    }
XIDDevice::~XIDDevice()
    {
    delete[] receiveBuffer;
    }


/*****************************************************************************

Routine Description:

    GetName

    Returns a textual description of this device, used for logging

Arguments:

    none

Return Value:

    char*   ptr to a global string

*****************************************************************************/
char* XIDDevice::GetName(void)
    {
    return DeviceName;
    }


/*****************************************************************************

Routine Description:

    Initialize

    Sets up the Endpoint settings on the simulator

Arguments:

    none

Return Value:

    DWORD   USBSIM error code (see "USBSimulator.h")

*****************************************************************************/
DWORD XIDDevice::Initialize(void)
    {
    DWORD error;
    unsigned i;

    data01 = 1;
    for(i=0; i<10; i++)
        enumerateState[i] = 0;

    LogPrint("Configuring endpoints.");

    // Endpoint 0
    error = SetupEndpoint(0, SIM_ENDPOINT_SETUP_TYPE_CONTROL, SIM_ENDPOINT_SETUP_SIZE_NOISOC64, SIM_ENDPOINT_SETUP_AUTO_DISABLED);

    // Other Endpoints
    for(i=1; i<4; i++)
        {
        error = SetupEndpoint(i, SIM_ENDPOINT_SETUP_TYPE_NOISOC, SIM_ENDPOINT_SETUP_SIZE_NOISOC64, SIM_ENDPOINT_SETUP_AUTO_DISABLED);
        }

    return error;
    }


/*****************************************************************************

Routine Description:

    Receive

    Handles all incomming packets

Arguments:

    none

Return Value:

    DWORD   USBSIM error code (see "USBSimulator.h")

Notes:


*****************************************************************************/
DWORD XIDDevice::Receive(void)
    {
    DWORD error = USBSIM_ERROR_OK;
    SimPacket *packet = (SimPacket*)receiveBuffer;
    USBPacket *usb = (USBPacket*)packet->data;

    // xid data request
    if(usb->pid == USB_PID_SETUP)
        {
        error = WaitForUSBPacket(SIM_CMD_USBDATA, SIM_SUBCMD_USBDATA, USB_PID_DATA0);
        if(error != USBSIM_ERROR_OK) return error;

        //
        // Get Device Descriptor
        //
        if(memcmp(usb->data, "\x80\x06\x00\x01\x00\x00\xff\x00", 8) == 0)
            {
            error = WaitForUSBPacket(SIM_CMD_USBDATA, SIM_SUBCMD_USBDATA, USB_PID_IN);
            if(error == USBSIM_ERROR_OK)
                {
                packet->command = SIM_CMD_USBDATA;
                packet->subcommand = SIM_SUBCMD_USBDATA;
                packet->dataSize = 9;
                memcpy(packet->data, "\xD2\x12\x01\x10\x01\x00\x00\x00\x08", packet->dataSize);
                send(sock, (char*)packet, packet->dataSize+sizeof(SimPacketHeader), 0);
                ++enumerateState[0];
                }
            }

        //
        // Set Address
        //
        else if(memcmp(usb->data, "\x00\x05", 2) == 0 && memcmp(usb->data+3, "\x00\x00\x00\x00\x00", 5) == 0)
            {
            error = WaitForUSBPacket(SIM_CMD_USBDATA, SIM_SUBCMD_USBDATA, USB_PID_IN);
            if(error == USBSIM_ERROR_OK)
                {
                packet->command = SIM_CMD_USBDATA;
                packet->subcommand = SIM_SUBCMD_USBDATA;
                packet->dataSize = 1;
                memcpy(packet->data, "\xD2", packet->dataSize);
                send(sock, (char*)packet, packet->dataSize+sizeof(SimPacketHeader), 0);

                packet->command = SIM_CMD_SETUP;
                packet->subcommand = SIM_SUBCMD_SETUP_USBADDRESS;
                packet->dataSize = 1;
                memcpy(packet->data, usb->data+2, packet->dataSize);
                send(sock, (char*)packet, packet->dataSize+sizeof(SimPacketHeader), 0);
                ++enumerateState[1];
                }
            }

        //
        // Get Configuration Descriptor
        //
        else if(memcmp(usb->data, "\x80\x06\x00\x02\x00\x00\x50\x00", 8) == 0)
            {
            error = WaitForUSBPacket(SIM_CMD_USBDATA, SIM_SUBCMD_USBDATA, USB_PID_IN);
            if(error == USBSIM_ERROR_OK)
                {
                packet->command = SIM_CMD_USBDATA;
                packet->subcommand = SIM_SUBCMD_USBDATA;
                packet->dataSize = 9;
                memcpy(packet->data, "\xD2\x09\x02\x29\x00\x01\x01\x04\x08", packet->dataSize);
                send(sock, (char*)packet, packet->dataSize+sizeof(SimPacketHeader), 0);
                ++enumerateState[2];
                }
            error = WaitForUSBPacket(SIM_CMD_USBDATA, SIM_SUBCMD_USBDATA, USB_PID_IN);
            if(error == USBSIM_ERROR_OK)
                {
                packet->command = SIM_CMD_USBDATA;
                packet->subcommand = SIM_SUBCMD_USBDATA;
                packet->dataSize = 9;
                memcpy(packet->data, "\xC3\x32\x09\x04\x00\x00\x02\x03\x00", packet->dataSize);
                send(sock, (char*)packet, packet->dataSize+sizeof(SimPacketHeader), 0);
                ++enumerateState[3];
                }
            error = WaitForUSBPacket(SIM_CMD_USBDATA, SIM_SUBCMD_USBDATA, USB_PID_IN);
            if(error == USBSIM_ERROR_OK)
                {
                packet->command = SIM_CMD_USBDATA;
                packet->subcommand = SIM_SUBCMD_USBDATA;
                packet->dataSize = 9;
                memcpy(packet->data, "\xD2\x00\x05\x09\x21\x10\x01\x00\x01", packet->dataSize);
                send(sock, (char*)packet, packet->dataSize+sizeof(SimPacketHeader), 0);
                ++enumerateState[4];
                }
            error = WaitForUSBPacket(SIM_CMD_USBDATA, SIM_SUBCMD_USBDATA, USB_PID_IN);
            if(error == USBSIM_ERROR_OK)
                {
                packet->command = SIM_CMD_USBDATA;
                packet->subcommand = SIM_SUBCMD_USBDATA;
                packet->dataSize = 9;
                memcpy(packet->data, "\xC3\x22\xC7\x00\x07\x05\x81\x03\x08", packet->dataSize);
                send(sock, (char*)packet, packet->dataSize+sizeof(SimPacketHeader), 0);
                ++enumerateState[5];
                }
            error = WaitForUSBPacket(SIM_CMD_USBDATA, SIM_SUBCMD_USBDATA, USB_PID_IN);
            if(error == USBSIM_ERROR_OK)
                {
                packet->command = SIM_CMD_USBDATA;
                packet->subcommand = SIM_SUBCMD_USBDATA;
                packet->dataSize = 9;
                memcpy(packet->data, "\xD2\x00\x01\x07\x05\x02\x03\x08\x00", packet->dataSize);
                send(sock, (char*)packet, packet->dataSize+sizeof(SimPacketHeader), 0);
                ++enumerateState[6];
                }
            error = WaitForUSBPacket(SIM_CMD_USBDATA, SIM_SUBCMD_USBDATA, USB_PID_IN);
            if(error == USBSIM_ERROR_OK)
                {
                packet->command = SIM_CMD_USBDATA;
                packet->subcommand = SIM_SUBCMD_USBDATA;
                packet->dataSize = 2;
                memcpy(packet->data, "\xC3\x01", packet->dataSize);
                send(sock, (char*)packet, packet->dataSize+sizeof(SimPacketHeader), 0);
                ++enumerateState[7];
                }
            }

        //
        // Set Configuration
        //
        else if(memcmp(usb->data, "\x00\x09\x01\x00\x00\x00\x00\x00", 8) == 0)
            {
            error = WaitForUSBPacket(SIM_CMD_USBDATA, SIM_SUBCMD_USBDATA, USB_PID_IN);
            if(error == USBSIM_ERROR_OK)
                {
                packet->command = SIM_CMD_USBDATA;
                packet->subcommand = SIM_SUBCMD_USBDATA;
                packet->dataSize = 1;
                memcpy(packet->data, "\xD2", packet->dataSize);
                send(sock, (char*)packet, packet->dataSize+sizeof(SimPacketHeader), 0);
                ++enumerateState[8];
                }
            }

        //
        // Get XID Descriptor
        //
        else if(memcmp(usb->data, "\xC1\x06\x00\x41\x00\x00\x08\x00", 8) == 0)
            {
            error = WaitForUSBPacket(SIM_CMD_USBDATA, SIM_SUBCMD_USBDATA, USB_PID_IN);
            if(error == USBSIM_ERROR_OK)
                {
                packet->command = SIM_CMD_USBDATA;
                packet->subcommand = SIM_SUBCMD_USBDATA;
                packet->dataSize = 9;
                memcpy(packet->data, "\xD2\x08\x41\x00\x01\x01\x01\x1A\x04", packet->dataSize);
                send(sock, (char*)packet, packet->dataSize+sizeof(SimPacketHeader), 0);
                ++enumerateState[9];
                }
            }
        }
    else if(usb->pid == USB_PID_IN)
        {
        packet->command = SIM_CMD_USBDATA;
        packet->subcommand = SIM_SUBCMD_USBDATA;
        packet->dataSize = USB_XID_PACKETSIZE + 1;
        Lock();
        memcpy(packet->data+1, &xidPacket, USB_XID_PACKETSIZE);
        Unlock();
        packet->data[0] = (unsigned char)(data01 ? USB_PID_DATA0 : USB_PID_DATA1);
        data01 = !data01;
        send(sock, (char*)packet, packet->dataSize+sizeof(SimPacketHeader), 0);
        }

    return error;
    }


/*****************************************************************************

Routine Description:


Arguments:


Return Value:


Notes:


*****************************************************************************/
DWORD XIDDevice::SetInputReport(XIDInputReport *xid)
    {
    Lock();
    if(xid)
        memcpy(xidPacket, xid, USB_XID_PACKETSIZE);
    else
        memcpy(xidPacket, &defaultXIDReport, USB_XID_PACKETSIZE);
    Unlock();

    return 0;
    }
DWORD XIDDevice::SetInputReport(unsigned __int8  reportID, unsigned __int8  size, unsigned __int16 buttons, unsigned __int8 *analogButtons, unsigned __int16 thumbLX, unsigned __int16 thumbLY, unsigned __int16 thumbRX, unsigned __int16 thumbRY)
    {
    XIDInputReport report = { reportID, size, buttons, {0, 0, 0, 0, 0, 0, 0, 0}, thumbLX, thumbLY, thumbRX, thumbRY };

    for(unsigned i=0; i<8; i++)
        report.analogButtons[i] = analogButtons[i];

    return SetInputReport(&report);
    }


/*****************************************************************************

Routine Description:


Arguments:


Return Value:


Notes:


*****************************************************************************/
bool XIDDevice::IsEnumerated(void)
    {
    bool enumed = true;
    for(unsigned i=0; i<10; i++)
        {
        if(enumerateState[i] == 0)
            {
            printf("   Enum piece %d is missing\n", i+1);
            enumed = false;
            }
        }

    if(enumed)
        {
        printf("   Duke enumerated!\n");
        }

    return enumed;
    }