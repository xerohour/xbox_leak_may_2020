USB Simulator 

Directories:

inc             Header files for USBSim.lib
USBSim.lib      Core C++ library for talking to simulators and handling Duke
test
test\ctrltest   C++ Console app looks for simulators and creates a Duke
test\simsim     C++ Console app that simulates the simulator
test\VBTestApp  VB App that does the same sort of thing as ctrltest

