/*----------------------------------------------------------------------------
 *  Copyright � 2000 Microsoft.  ALL RIGHTS RESERVED. 
 *----------------------------------------------------------------------------
 *  Date: 11/14/00
 *  Developer: Sean Wohlgemuth
 *  Description: Windows Scripting Host Script
 *----------------------------------------------------------------------------
 */

//////////////////////////////////////////////////////////////////////////////
// This function will allow multiple JScript file Includes
//////////////////////////////////////////////////////////////////////////////
function include(sFile)
{
  WScript.Echo("Include File : " + sFile);
  var objFSO = WScript.CreateObject("Scripting.FileSystemObject");
  var objInc = objFSO.OpenTextFile(sFile, 1);
  return objInc.ReadAll();
}//endmethod

//////////////////////////////////////////////////////////////////////////////
// Include
//////////////////////////////////////////////////////////////////////////////
eval(include("Common\\services.js"));
eval(include("config.js"));

//////////////////////////////////////////////////////////////////////////////
// Global Variables
//////////////////////////////////////////////////////////////////////////////
var engine = WScript.CreateObject("Surge.Engine");

//////////////////////////////////////////////////////////////////////////////
// ***** ENTRY POINT *****
//////////////////////////////////////////////////////////////////////////////
function main(){
	bRetVal=true;

	//Contact redirector
	var pszRegion="0x0409";
	var rgService=new Array();
	bRetVal=QueryRedirector(pszRedirServer,pszRegion,rgService);
	if (false==bRetVal) {
		DebugPrint(ERROR,"Redirector failed.");
		return false;
	}//endif

	//Authenticate
	var pszVersion="1.0";
	var pszXBoxID="123456789";
	var pszTitleID="1634";
	var pszTitleRevision="1";
	var pszRandom="3242423";
	var rgAppServer=new Array();
	var rgUser=new Array();
	var rgHashedUserKey=new Array();
	rgAppServer[0]="XSTATS";
	rgUser[0]="seanwo@zone";
	rgHashedUserKey[0]="12345678901234567890123456789012";
	var rgTicket=new Array();
	var rgError=new Array();
	bRetVal=Authenticate(MapLookup("xauth",rgService),pszVersion,pszXBoxID,pszTitleID,pszTitleRevision,pszRandom,rgAppServer,rgUser,rgHashedUserKey,rgTicket,rgError);
	if (false==bRetVal){
		DebugPrint(ERROR,"Authenticate failed.");
		return false;
	}//endif

	//Summary
	WScript.Echo("Tickets: "+rgTicket.length);
	WScript.Echo("Errors: "+rgError.length);
	return true;

}//endemthod

if (false==main()){
	DebugPrint(ERROR,"FAILURE!");
}//endif