/*----------------------------------------------------------------------------
 *  Copyright � 2000 Microsoft.  ALL RIGHTS RESERVED. 
 *----------------------------------------------------------------------------
 *  Date: 12/12/00
 *  Developer: Sean Wohlgemuth
 *  Description: Windows Scripting Host Script
 *----------------------------------------------------------------------------
 */

DEBUG=ERROR;
//DEBUG=TRACE;
//DEBUG=WARNING;
//DEBUG=INFO;
//DEBUG=SPEW;

var pszRedirServer="xolab-1"