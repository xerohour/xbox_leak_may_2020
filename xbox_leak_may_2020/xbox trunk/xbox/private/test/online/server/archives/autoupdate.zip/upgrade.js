/*----------------------------------------------------------------------------
 *  Copyright � 2000 Microsoft.  ALL RIGHTS RESERVED. 
 *----------------------------------------------------------------------------
 *  Date: 12/14/00
 *  Developer: Sean Wohlgemuth
 *  Description: Window scripting host script used to upgrade servers
 *----------------------------------------------------------------------------
 */

//**********
//********** Globals (Source)
//**********
var WSHShell = WScript.CreateObject("WScript.Shell");
var WSHNetwork = WScript.CreateObject("WScript.Network");
var fso = new ActiveXObject("Scripting.FileSystemObject");
var logfile;
var oDate;

//**********
//********** Globals (Configuration)
//**********
var clustername="XOLAB";
var xolab1_files=new Array();
var xolab1_commands=new Array();
var xolab2_files=new Array();
var xolab2_commands=new Array();
var xolab3_files=
	new Array(
		new Array("webstore\\*.*","\\\\xolab-3\\d$\\wwwroot\\webstore"),
		new Array("webstore\\ini\\webstore_testlab.ini","\\\\xolab-3\\d$\\wwwroot\\webstore\\webstore.ini"),
		new Array("xxaccount\\xxaccount.dll","\\\\xolab-3\\d$\\wwwroot\\xxaccount"),
		new Array("xauthstorage\\xauthstorage.dll","\\\\xolab-3\\d$\\wwwroot\\xauthstorage"),
		new Array("xextension\\xextension.dll","\\\\xolab-3\\d$\\wwwroot\\xextension"),
		//new Array("xextension\\XExtConfig.ini","\\\\xolab-3\\d$\\wwwroot\\xextension"),
		new Array("xmachineinfomgmt\\xmachineinfomgmt.dll","\\\\xolab-3\\d$\\wwwroot\\xmachineinfomgmt"),
		new Array("common\\xheap.dll","\\\\xolab-3\\d$\\wwwroot\\xxaccount"),
		new Array("common\\xheap.dll","\\\\xolab-3\\d$\\wwwroot\\xauthstorage"),
		new Array("common\\xheap.dll","\\\\xolab-3\\d$\\wwwroot\\xmachineinfomgmt")
	);
var xolab3_commands=new Array(
	"c:\\winnt\\system32\\regsvr32.exe /s d:\\wwwroot\\xauthstorage\\xauthstorage.dll",
	"c:\\winnt\\system32\\regsvr32.exe /s d:\\wwwroot\\xxacount\\xxaccount.dll",
	"c:\\winnt\\system32\\regsvr32.exe /s d:\\wwwroot\\xextension\\xextension.dll",
	"c:\\winnt\\system32\\regsvr32.exe /s d:\\wwwroot\\xmachineinfomgmt\\xmachineinfomgmt.dll",
	"c:\\winnt\\system32\\regsvr32.exe /s d:\\wwwroot\\webstore\\wststore.dll"
);
var xolab4_files=
	new Array(
		new Array("xauth\\xauth.dll","\\\\xolab-4\\d$\\wwwroot\\xauth"),
		new Array("xextension\\xextension.dll","\\\\xolab-4\\d$\\wwwroot\\xextension"),
		//new Array("xextension\\XExtConfig.ini","\\\\xolab-4\\d$\\wwwroot\\xextension"),
		new Array("common\\xheap.dll","\\\\xolab-4\\d$\\wwwroot\\xauth"),
		new Array("common\\xheap.dll","\\\\xolab-4\\d$\\wwwroot\\xextension"),
		new Array("common\\xhash.dll","\\\\xolab-4\\d$\\wwwroot\\xextension")
	);
var xolab4_commands=new Array(
	"c:\\winnt\\system32\\regsvr32.exe /s d:\\wwwroot\\xextension\\xextension.dll",
	"c:\\winnt\\system32\\regsvr32.exe /s d:\\wwwroot\\xauth\\xauth.dll"
);
var xolab5_files=new Array();
var xolab5_commands=new Array();
var xolab6_files=
	new Array(
		new Array("xauthfilter\\xauthfilter.dll","\\\\xolab-6\\d$\\wwwroot\\xauthfilter"),
		new Array("common\\xheap.dll","\\\\xolab-6\\d$\\wwwroot\\xauthfilter")
	);
var xolab6_commands=new Array();
var cluster=
	new Array(
		new Array("xolab-1",xolab1_commands,xolab1_files),
		new Array("xolab-3",xolab3_commands,xolab3_files),
		new Array("xolab-4",xolab4_commands,xolab4_files),
		new Array("xolab-6",xolab6_commands,xolab6_files)
	);
var symboldir = WSHShell.ExpandEnvironmentStrings("%windir%")+"\\symbols\dll";
var build_machine="xbuilds";
var build_type="free";
var build_base_path="\\\\"+build_machine+"\\release\\usa";
var library_path="\\online";
var symbol_path="\\symbols\\online\\dll";
var install_dir="c:\\autoup";
var mail_smtp_server="smarthost";
var mail_to="xonauto@microsoft.com";
var mail_from="xonauto@microsoft.com";
var local_build_file=WSHShell.ExpandEnvironmentStrings("%windir%")+"\\localbld.txt"
var contactinfo="Sean Wohlgemuth <seanwo@microsoft.com>";

//**********
//********** Get_Latest_Build
//**********
function Get_Latest_Build(path){

	var fso; //file system object
	var folder; //folder object
	var foldercollection; //folder collection object
	var build; //current folder build number
	var latestbuild; //latest build folder found

	//get folder object to build directory; return if folder does not exist
	fso = new ActiveXObject("Scripting.FileSystemObject");
	try{
		folder = fso.GetFolder(path);
	}catch(e){
		return -1;
	}//endcatch

	//enumerate subfolders into folder collection
	foldercollection = new Enumerator(folder.subfolders);

	//if folder is empty return
	if (foldercollection.atEnd())
		return -2;

	//initialize latest build to 0
	latestbuild=new Number(0);

	//search for the latest build
	for (; !foldercollection.atEnd(); foldercollection.moveNext())
	{
		build = new Number(foldercollection.item().shortname);
		if (build>latestbuild){
			latestbuild=build;
		}//endif
	}//endfor

	return(latestbuild);

}//endmethod

//**********
//********** Get_Local_Build
//**********
function Get_Local_Build(){

	var ForReading = 1; //OpenTextFile constant
	var build; //build number

	//open the local build file and grab the local build
	var fso = new ActiveXObject("Scripting.FileSystemObject");
	try{
		f = fso.OpenTextFile(local_build_file, ForReading);
		build = new Number(f.ReadLine())
		f.Close();
	}catch(e){
		build = new Number(0);
	}//endcatch

	return build;

}//endmethod

//**********
//********** Set_Local_Build
//**********
function Set_Local_Build(build){

	var fso; //file system object
	var f; //file

	//create file and write build to it
	fso = new ActiveXObject("Scripting.FileSystemObject");
	try{
		f = fso.CreateTextFile(local_build_file, true);
		f.WriteLine(build.toString());
		f.Close();
	}catch(e){
		return -1;
	}//endcatch

	return 0;

}//endmethod

//**********
//********** Send_Down_Mail
//**********
function Send_Down_Mail()
{
	//Send the mail

	var pszSubject=clustername+" CLUSTER IS GOING DOWN FOR UPGRADE";

	//create mail file and write build to it
	fso = new ActiveXObject("Scripting.FileSystemObject");
	try{
		f = fso.CreateTextFile(install_dir+"\\mail.txt", true);
		f.WriteLine(clustername+" cluster is going down for a schedule upgrade.");
		f.WriteLine("");
		f.WriteLine("For questions or comments, please contact: "+contactinfo);
		f.Close();
	}catch(e){
		return -1;
	}//endcatch

	try{
		WSHShell.Run(install_dir+"\\blat.exe "+install_dir+"\\mail.txt -server "+mail_smtp_server+" -t "+mail_to+" -f "+mail_from+" -s \""+pszSubject+"\"",0,true);
		fso.DeleteFile(install_dir+"\\mail.txt");
	}catch(e){
		return -1;
	}//endcatch

	return 0;

}//endmethod

//**********
//********** Send_Up_Mail
//**********
function Send_Up_Mail(build)
{
	//Send the mail

	var pszSubject=clustername+" CLUSTER IS RUNNING BUILD "+build;

	//create mail file and write build to it
	fso = new ActiveXObject("Scripting.FileSystemObject");
	try{
		f = fso.CreateTextFile(install_dir+"\\mail.txt", true);
		f.WriteLine(clustername+" cluster is now up and running build "+build+".");
		f.WriteLine("");
		f.WriteLine("For questions or comments, please contact: "+contactinfo);
		f.Close();
	}catch(e){
		return -1;
	}//endcatch

	try{
		WSHShell.Run(install_dir+"\\blat.exe "+install_dir+"\\mail.txt -server "+mail_smtp_server+" -t "+mail_to+" -f "+mail_from+" -s \""+pszSubject+"\"",0,true);
		fso.DeleteFile(install_dir+"\\mail.txt");
	}catch(e){
		return -1;
	}//endcatch

	return 0;

}//endmethod

//**********
//********** Send_Disable_Mail
//**********
function Send_Disable_Mail()
{
	//Send the mail

	var pszSubject=clustername+" AUTO UPGRADE HAS BEEN DISABLED";

	//create mail file and write build to it
	fso = new ActiveXObject("Scripting.FileSystemObject");
	try{
		f = fso.CreateTextFile(install_dir+"\\mail.txt", true);
		f.WriteLine("Problems were detected during the auto upgrade.  The system administrator has been notified.");
		f.WriteLine("");
		f.WriteLine("For questions or comments, please contact: "+contactinfo);
		f.Close();
	}catch(e){
		return -1;
	}//endcatch

	try{
		WSHShell.Run(install_dir+"\\blat.exe "+install_dir+"\\mail.txt -server "+mail_smtp_server+" -t "+mail_to+" -f "+mail_from+" -s \""+pszSubject+"\"",0,true);
		fso.DeleteFile(install_dir+"\\mail.txt");
	}catch(e){
		return -1;
	}//endcatch

	return 0;

}//endmethod

//**********
//********** Upgrade
//**********
function Upgrade(localbuild, dropbuild, bForce, pszShare){

	//Do we need to upgrade?
	if ((bForce==false) && (localbuild.valueOf()==dropbuild.valueOf())){
		return -2;
	}//endif	

	//Send server going down mail
	if (0!=Send_Down_Mail()){
		return -1;
	}//endif
	logfile.WriteLine("cluster going down mail sent.");

	var build_library_path;
	var build_symbol_path;

	if (pszShare==""){
		build_library_path=build_base_path+"\\"+dropbuild+"\\"+build_type+library_path;
		build_symbol_path=build_base_path+"\\"+dropbuild+"\\"+build_type+symbol_path;
	}else{
		build_library_path=pszShare+library_path;
		build_symbol_path=pszShare+symbol_path;
	}//endif
	logfile.WriteLine("library path: "+build_library_path);
	logfile.WriteLine("symbol path: "+build_symbol_path);

	for (iMachine=0; iMachine<cluster.length; iMachine++){
		try{
			cmd=install_dir+"\\rcmd.exe \\\\"+cluster[iMachine][0]+" c:\\winnt\\system32\\net.exe stop iisadmin /yes";
			retcode=WSHShell.Run(cmd,0,true);
			logfile.WriteLine("executed(retcode:"+retcode+"): "+cmd);
			if (retcode!=1){ 
				throw "iisadmin service shutdown error!";
			}//endif
			for (iFiles=0; iFiles<cluster[iMachine][2].length; iFiles++){
				cmd=WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\xcopy.exe /y /r /i "+build_library_path+"\\"+cluster[iMachine][2][iFiles][0]+" "+cluster[iMachine][2][iFiles][1];
				retcode=WSHShell.Run(cmd,0,true);
				logfile.WriteLine("executed(retcode:"+retcode+"): "+cmd);
				if (retcode!=0){ 
					throw "xcopy error!";
				}//endif
			}//endfor
			cmd=WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\xcopy.exe /y /r /i "+build_symbol_path+"\\*.* \\\\"+cluster[iMachine][0]+"\\c$\\winnt\\symbols\\dll";
			retcode=WSHShell.Run(cmd,0,true);
			logfile.WriteLine("executed(retcode:"+retcode+"): "+cmd);
			if (retcode!=0){ 
				throw "xcopy error!";
			}//endif
			for (iCommands=0; iCommands<cluster[iMachine][1].length; iCommands++){
				cmd=install_dir+"\\rcmd.exe \\\\"+cluster[iMachine][0]+" "+(cluster[iMachine][1])[iCommands];
				retcode=WSHShell.Run(cmd,0,true);
				logfile.WriteLine("executed(retcode:"+retcode+"): "+cmd);
				if (retcode!=1){ 
					throw "remote command error!";
				}//endif
			}//endfor
			cmd=install_dir+"\\rcmd.exe \\\\"+cluster[iMachine][0]+" c:\\winnt\\system32\\net.exe start w3svc";
			retcode=WSHShell.Run(cmd,0,true);
			logfile.WriteLine("executed(retcode:"+retcode+"): "+cmd);
			if (retcode!=1){ 
				throw "w3svc service startup error!";
			}//endif
		}catch(e){
			logfile.WriteLine("exception raised: "+e);
			//DISABLE UPGRADES
			Set_Local_Build(-1);
			Send_Disable_Mail();
			return -1;
		}//endcatch
	}//endfor	

	//Send server back up mail
	if (pszShare!=""){
		if (0!=Send_Up_Mail("PRIVATE")){
			return -1;
		}//endif
	}else{
		if (0!=Send_Up_Mail(dropbuild)){
			return -1;
		}//endif
	}//endelse
	logfile.WriteLine("cluster up mail sent.");

	//Set local build
	if (pszShare==""){
		if (0!=Set_Local_Build(dropbuild)){
			return -1;
		}//endif
	}//endif

	return 0;

}//endmethod

//**********
//********** Main Block
//**********

var objArgs = WScript.Arguments;

	var bExit=false;
	var bValid=false;
	var bForce=false;
	var pszShare="";
	if (objArgs.Count()>0){

		//INSTALL
		if (objArgs(0).toLowerCase()=="install"){
			bExit=true;
			bValid=true;
			try{
				WSHShell.Run("at 0:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 1:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 2:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 3:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 4:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 5:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 6:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 7:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 8:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 9:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 10:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 11:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 12:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 13:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 14:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 15:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 16:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 17:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 18:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 19:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 20:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 21:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 22:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
				WSHShell.Run("at 23:00 /every:monday,tuesday,wednesday,thursday,friday,saturday,sunday "+WSHShell.ExpandEnvironmentStrings("%windir%")+"\\system32\\cscript.exe "+install_dir+"\\upgrade.js",0,true);
			}catch(e){
			}//endcatch
		}//endif

		//UNINSTALL
		if (objArgs(0).toLowerCase()=="uninstall"){
			bExit=true;
			bValid=true;
			try{
				WSHShell.Run("at /delete /yes",0,true);
			}catch(e){
			}//endcatch
		}//endif

		//FORCE
		if (objArgs(0).toLowerCase()=="-f"){
			bExit=false;
			bValid=true;
			bForce=true;
			if (objArgs.Count()>1){
				pszShare=objArgs(1);
			}//endif
		}//endif

		//DISPLAY USAGE
		if (bValid!=true){
			bExit=true;
			bValid=true;
			WScript.Echo("usage: cscript upgrade.js [ install | uninstall ] | [-f [\\\\server\\share]] | [help]\r\n");
			WScript.Echo("examples:");
			WScript.Echo("cscript upgrade.js help               [display usage]");
			WScript.Echo("cscript upgrade.js install            [install AT jobs]");
			WScript.Echo("cscript upgrade.js uninstall          [uninstall all AT jobs]");
			WScript.Echo("cscript upgrade.js                    [upgrade if needed]");
			WScript.Echo("cscript upgrade.js -f                 [force upgrade]\r\n");
			WScript.Echo("cscript upgrade.js -f \\\\mybox\\drop    [force upgrade from share]\r\n");
			WScript.Echo("notes: rcmd service must be installed on target machines and this script must be run by a user that has admin access on target machines.");
		}//endif
	}//endif

	if (bExit!=true){

		//UPGRADE
		var dropbuild = Get_Latest_Build(build_base_path);
		var localbuild = Get_Local_Build();

		if (((bForce==true) && (pszShare!="")) || ((dropbuild>0) && (localbuild>=0))){
			logfile = fso.OpenTextFile(install_dir+"\\log.txt", 8, true);
			oDate=new Date();
			logfile.WriteLine(oDate.toUTCString());
			logfile.WriteLine("dropbuild="+dropbuild+" localbuild="+localbuild);
			switch (Upgrade(localbuild,dropbuild,bForce,pszShare)){
				case 0:
					logfile.WriteLine("Upgrade Successful.");
					break;
				case -1:
					logfile.WriteLine("Upgrade Failed.");
					break;
				default:
			}//Switch
			logfile.Close();
		}//endif
	}//endif

//endmain