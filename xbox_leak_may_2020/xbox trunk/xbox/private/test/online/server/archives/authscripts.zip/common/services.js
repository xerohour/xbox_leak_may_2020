/*----------------------------------------------------------------------------
 *  Copyright � 2000 Microsoft.  ALL RIGHTS RESERVED. 
 *----------------------------------------------------------------------------
 *  Date: 11/14/00
 *  Developer: Sean Wohlgemuth
 *  Description: Windows Scripting Host Script
 *----------------------------------------------------------------------------
 */

//////////////////////////////////////////////////////////////////////////////
// This function will allow multiple JScript file Includes
//////////////////////////////////////////////////////////////////////////////
function include(sFile)
{
  WScript.Echo("Include File : " + sFile);
  var objFSO = WScript.CreateObject("Scripting.FileSystemObject");
  var objInc = objFSO.OpenTextFile(sFile, 1);
  return objInc.ReadAll();
}//endmethod

//////////////////////////////////////////////////////////////////////////////
// Include
//////////////////////////////////////////////////////////////////////////////
eval(include("Common\\utils.js"));

var pszRelAuthPath="xauth/xauth.xbp";
var pszRelRedirPath="redirect.xbp";

//////////////////////////////////////////////////////////////////////////////
// Connect to redirect server and return list of services
//////////////////////////////////////////////////////////////////////////////
function QueryRedirector(/*[in]*/pszRedirIP, /*[in]*/pszRegion, /*[out]*/rgService){

	//Parameter checks
	if (null==pszRedirIP) return false;
	if (null==pszRegion) return false;
	if (null==rgService) return false;
	if ("string"!=typeof(pszRedirIP)) return false;
	if ("string"!=typeof(pszRegion)) return false;
	if ("object"!=typeof(rgService)) return false;

	//Initialize out parameters
	rgService.length=0;

	//GET redirect
	var pszRedirRequest="http://"+pszRedirIP+"/"+pszRelRedirPath+"?region="+pszRegion;
	engine.getFullPage = true;
	engine.GET(pszRedirRequest);
	DebugPrint(INFO,"redir server request: "+pszRedirRequest);

	//If status is not 200 OK return failure
	if (200!=engine.httpStatus) {
		DebugPrint(ERROR,"Invalid response from redir server. Status="+engine.httpStatus);
		return false;
	}//endif

	//Get the response
	var Buffer=new Reference();
	Buffer.value=engine.GetBody();
	DebugPrint(INFO,"redir server response: "+engine.GetBody());
	
	//Parse out the services and the IPs
	var l_Map=new Map();
	var icIndex=0;
	var Line=new Reference();
	while (true){
	
		//Get a line of the buffer
		Line.value=NextLine(Buffer);
		if (Line.value.valueOf()=="") break;

		//Search for seperator and divide out into index and item
		l_Map.Index=ScanForward(Line,new RegExp(",","g"));
		if (l_Map.Index.valueof!=""){
			Line.value=Line.value.substr(1,Line.value.length);
			l_Map.Item=Line.value;
		}//endif

		//Store the service in return array
		rgService[icIndex]=new Map();
		rgService[icIndex].Index=l_Map.Index;
		rgService[icIndex++].Item=l_Map.Item;
		
	}//endwhile

	//Success
	return true;

}//endmethod

//////////////////////////////////////////////////////////////////////////////
// Connect to authentication server and return tickets or errors
//////////////////////////////////////////////////////////////////////////////
function Authenticate(/*[in]*/pszAuthIP, /*[in]*/pszVersion, /*[in]*/pszXBoxID, /*[in]*/pszTitleID, /*[in]*/pszTitleRevision, /*[in]*/pszRandom, /*[in]*/rgAppServer, /*[in]*/rgUser, /*[in]*/rgHashedUserKey, /*[out]*/rgTicket, /*[out]*/rgError){

	//Check parameters
	if (null==pszAuthIP) return false;
	if (null==pszVersion) return false;
	if (null==pszXBoxID) return false;
	if (null==pszTitleID) return false;
	if (null==rgAppServer) return false;
	if (null==rgUser) return false;
	if (null==rgHashedUserKey) return false;
	if (null==rgTicket) return false;
	if (null==rgError) return false;
	if ("string"!=typeof(pszAuthIP)) return false;
	if ("string"!=typeof(pszVersion)) return false;
	if ("string"!=typeof(pszXBoxID)) return false;
	if ("string"!=typeof(pszTitleID)) return false;
	if ("object"!=typeof(rgAppServer)) return false;
	if ("object"!=typeof(rgUser)) return false;
	if ("object"!=typeof(rgHashedUserKey)) return false;
	if ("object"!=typeof(rgTicket)) return false;
	if ("object"!=typeof(rgError)) return false;
	if (0==rgAppServer.length) return false;
	if (0==rgUser.length) return false;
	if (0==rgHashedUserKey.length) return false;
	if (rgUser.length!=rgHashedUserKey.length) return false;

	//Initialize out parameters
	rgTicket.length=0;
	rgError.length=0;

	iPortIndex=pszAuthIP.search(":");
	if (iPortIndex!=-1){
		pszPort=pszAuthIP.substr(iPortIndex+1);
		pszAuthIP=pszAuthIP.substring(0,iPortIndex);
		DebugPrint(INFO,"setting request port to: "+pszPort);
		engine.tcpPort=pszPort;
	}//endif

	//Build auth request string
	pszAuthRequest="http://"+pszAuthIP+
		"/"+pszRelAuthPath+
		"?v="+pszVersion+
		"&x="+pszXBoxID+
		"&t="+pszTitleID+
		"&r="+pszTitleRevision+
		"&n="+pszRandom;
	for (i=0; i<rgAppServer.length; i++){
		pszAuthRequest+="&s"+(i+1)+"="+rgAppServer[i];
	}//endfor
	for (i=0; i<rgUser.length; i++){
		pszAuthRequest+="&u"+(i+1)+"="+rgUser[i];
		pszAuthRequest+="&h"+(i+1)+"="+rgHashedUserKey[i];
	}//endfor

	//Send request
	engine.getFullPage = true;
	engine.Get(pszAuthRequest);
	engine.tcpPort=80;

	DebugPrint(INFO,"auth server request: "+pszAuthRequest);

	//If status is not 200 or 400 return failure
	var iStatus=engine.httpStatus;
	if ((400!=iStatus) && (200!=iStatus)) {
		DebugPrint(ERROR,"Invalid response from auth server. Status="+iStatus);
		return false;
	}//endif

	//Get the response
	var Buffer=new Reference();
	Buffer.value=engine.GetBody();
	DebugPrint(INFO,"auth server response: "+engine.GetBody());

	//Parse out the application servers and tickets or errors
	var l_Map=new Map();
	var icIndex=0;
	var Line=new Reference();
	while (true){
	
		//Get a line of the buffer
		Line.value=NextLine(Buffer);
		if (Line.value.valueOf()=="") break;

		//Search for seperator and divide out into index and item
		if (iStatus==200){
			l_Map.Index=ScanForward(Line,new RegExp("=","g"));
		}else{
			l_Map.Index=ScanForward(Line,new RegExp(" ","g"));
		}//endelse

		if (l_Map.Index.valueof!=""){
			Line.value=Line.value.substr(1,Line.value.length);
			l_Map.Item=Line.value;
		}//endif

		//Store the errors or tickets in return array
		if (iStatus==200){
			rgTicket[icIndex]=new Map();
			rgTicket[icIndex].Index=l_Map.Index;
			rgTicket[icIndex++].Item=l_Map.Item;
		}else{
			rgError[icIndex]=new Map();
			rgError[icIndex].Index=l_Map.Index;
			rgError[icIndex++].Item=l_Map.Item;
		}//endelse

	}//endwhile

	return true;

}//endmethod
