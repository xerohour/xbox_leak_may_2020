/*----------------------------------------------------------------------------
 *  Copyright � 2000 Microsoft.  ALL RIGHTS RESERVED. 
 *----------------------------------------------------------------------------
 *  Date: 11/14/00
 *  Developer: Sean Wohlgemuth
 *  Description: Windows Scripting Host Script
 *----------------------------------------------------------------------------
 */

//////////////////////////////////////////////////////////////////////////////
// Structures
//////////////////////////////////////////////////////////////////////////////

function Map(){
	this.Index="";
	this.Item="";
}//endmethod

function Reference(){
	this.value="";
}//endmethod

//////////////////////////////////////////////////////////////////////////////
// Debug print
//////////////////////////////////////////////////////////////////////////////
var TRACE=0x01;
var WARNING=0x02;
var ERROR=0x04;
var INFO=0x08;
var SPEW=TRACE+WARNING+ERROR+INFO;
var DEBUG=ERROR;

function DebugPrint(/*[in]*/iLevel, /*[in]*/pszDebug){
	if ((iLevel&DEBUG)>0){
		WScript.Echo(pszDebug);
	}//endif
}//endmethod

//////////////////////////////////////////////////////////////////////////////
// Return a line from the buffer and advance buffer object to next line
//////////////////////////////////////////////////////////////////////////////
function NextLine(/*[in/out]*/pStringRef){
	var pszRetval="";
	var iIndex=-1;

	//Parameter checks
	if (null==pStringRef) return pszRetval;
	if ("object"!=typeof(pStringRef)) return pszRetval;
	if ("string"!=typeof(pStringRef.value)) return pszRetval;

	//Search for end of line
	iIndex=pStringRef.value.search(/\r\n/g);
	if (-1!=iIndex){
		//Set return value; advance the line
		pszRetval=pStringRef.value.substr(0,iIndex);
		pStringRef.value=pStringRef.value.substr(iIndex+2,pStringRef.value.length);
	}else{
		//Set the return value to whole string; advance to end
		pszRetval=pStringRef.value;
		pStringRef.value="";
	}//endelse

	return pszRetval;

}//endmethod

//////////////////////////////////////////////////////////////////////////////
// Lookup an item based on index
//////////////////////////////////////////////////////////////////////////////
function MapLookup(/*[in]*/Index, /*[in]*/rgMap){

	//Parameter checks
	if (null==Index) return "";
	if (null==rgMap) return "";
	if ("object"!=typeof(rgMap)) return "";
	if (rgMap.length==0) return "";

	//Search through map for index; if found return item
	for (i=0; i<rgMap.length; i++){
		if (Index.valueOf()==rgMap[i].Index.valueOf()){
			return rgMap[i].Item;
		}//endif
	}//endfor

	//Not found
	return "";

}//endmethod

//////////////////////////////////////////////////////////////////////////////
//  Scan forward for the expression; advance the string ref and return the 
//  the string before the expression.
//////////////////////////////////////////////////////////////////////////////
function ScanForward(/*[in/out]*/pStringRef, /*[in]*/Expression){
	var pszRetval="";
	var iIndex=-1;
	
	//Parameter checks
	if (null==pStringRef) return pszRetval;
	if (null==Expression) return pszRetval;
	if ("object"!=typeof(pStringRef)) return pszRetval;
	if ("object"!=typeof(Expression)) return pszRetval;
	if ("string"!=typeof(pStringRef.value)) return pszRetval;
	
	//Search for the expression
	iIndex=pStringRef.value.search(Expression);
	if (-1 != iIndex){
		//Return the string preceeding the search string; advance the string
		pszRetval=pStringRef.value.substr(0,iIndex);
		pStringRef.value=pStringRef.value.substr(iIndex,pStringRef.value.length);		
	}else{
		pszRetval=pStringRef.value;
	}//endif

	return pszRetval;

}//endmethod