/****************************************************************************
 *
 *  3DSROBJ.C
 *
 *  (C) Copyright 1997 by Autodesk, Inc.
 *
 *  This program is copyrighted by Autodesk, Inc. and is licensed to you under
 *  the following conditions.  You may not distribute or publish the source
 *  code of this program in any form.  You may incorporate this code in object
 *  form in derivative works provided such derivative works are (i.) are de-
 *  signed and intended to work solely with Autodesk, Inc. products, and (ii.)
 *  contain Autodesk's copyright notice "(C) Copyright 1995 by Autodesk, Inc."
 *
 *  AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.  AUTODESK SPE-
 *  CIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 *  A PARTICULAR USE.  AUTODESK, INC.  DOES NOT WARRANT THAT THE OPERATION OF
 *  THE PROGRAM WILL BE UNINTERRUPTED OR ERROR FREE.
 *
 ***************************************************************************/

#include <malloc.h>
#include <stdlib.h>
#include <assert.h>
#include "3dstype.h"
#include "3dserr.h"
#include "3dsmobj.h"
#include "3dsrobj.h"

void RelMeshObjField3ds(mesh3ds *obj, ushort3ds field)
{
   ulong3ds i;

   assert(obj != NULL);

   if ((field & RelVertexArray3ds) == RelVertexArray3ds)
   {
      if (obj->vertexarray != NULL)
         {free(obj->vertexarray); obj->vertexarray = NULL;}
   }
   if ((field & RelTextArray3ds) == RelTextArray3ds)
   {
      if (obj->textarray != NULL)
         {free(obj->textarray); obj->textarray = NULL;}
   }
   if ((field & RelFaceArray3ds) == RelFaceArray3ds)
   {
      if (obj->facearray != NULL)
         {free(obj->facearray); obj->facearray = NULL;}
   }
   if ((field & RelMatArray3ds) == RelMatArray3ds)
   {
      if (obj->matarray != NULL)
      {
         for (i = 0; i < obj->nmats; i++)
         {
            if (obj->matarray[i].faceindex != NULL)
               {free(obj->matarray[i].faceindex); obj->matarray[i].faceindex = NULL;}
         }
         free(obj->matarray); (obj->matarray = NULL);

      }
   }
   if ((field & RelSmoothArray3ds) == RelSmoothArray3ds)
   {
      if (obj->smootharray != NULL)
         {free(obj->smootharray); obj->smootharray = NULL;}
   }
   if ((field & RelProcData3ds) == RelProcData3ds)
   {
      if (obj->procdata != NULL)
         {free(obj->procdata); obj->procdata = NULL;}
   }

   if ((field & RelVFlagArray3ds) == RelVFlagArray3ds)
   {
      if (obj->vflagarray != NULL)
      {
	 free(obj->vflagarray); obj->vflagarray = NULL;
      }
   }
   
}

void RelMeshObj3ds(mesh3ds **obj)
{
   if ((obj != NULL) && (*obj != NULL))
   {
      RelMeshObjField3ds(*obj, RelVertexArray3ds);
      RelMeshObjField3ds(*obj, RelTextArray3ds);
      RelMeshObjField3ds(*obj, RelFaceArray3ds);
      RelMeshObjField3ds(*obj, RelMatArray3ds);
      RelMeshObjField3ds(*obj, RelSmoothArray3ds);
      RelMeshObjField3ds(*obj, RelProcData3ds);
      RelMeshObjField3ds(*obj, RelVFlagArray3ds);
   
      free(*obj);
   }

   *obj = NULL;

}

