/****************************************************************************
 *
 *  MDATA3DS.C
 *
 *  (C) Copyright 1997 by Autodesk, Inc.
 *
 *  This program is copyrighted by Autodesk, Inc. and is licensed to you under
 *  the following conditions.  You may not distribute or publish the source
 *  code of this program in any form.  You may incorporate this code in object
 *  form in derivative works provided such derivative works are (i.) are de-
 *  signed and intended to work solely with Autodesk, Inc. products, and (ii.)
 *  contain Autodesk's copyright notice "(C) Copyright 1995 by Autodesk, Inc."
 *
 *  AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.  AUTODESK SPE-
 *  CIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 *  A PARTICULAR USE.  AUTODESK, INC.  DOES NOT WARRANT THAT THE OPERATION OF
 *  THE PROGRAM WILL BE UNINTERRUPTED OR ERROR FREE.
 *
 ***************************************************************************/

#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <malloc.h>
#include "3dstype.h"
#include "3dsfile.h"
#include "dbase3ds.h"
#include "3dsftkst.h"
#include "mdata3ds.h"
#include "3dserr.h"

void GetMeshSectionChunk3ds(database3ds *db, chunk3ds **mdata)
{
   myassert(db != NULL, "GetMeshSectionChunk3ds: arg *db cannot be NULL");
   myassert(mdata != NULL, "GetMeshSectionChunk3ds: arg **mdata cannot be NULL");

   FindNextChunk3ds(db->topchunk->children, MDATA, mdata);
   if (*mdata == NULL)
   {
      InitChunkAs3ds(mdata, MDATA);
      ON_ERROR_RETURN;

      AddChildOrdered3ds(db->topchunk, *mdata);
      ON_ERROR_RETURN;
   } 
}

