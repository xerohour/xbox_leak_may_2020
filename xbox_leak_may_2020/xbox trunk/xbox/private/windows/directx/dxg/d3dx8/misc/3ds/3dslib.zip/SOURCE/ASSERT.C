/****************************************************************************
 *
 *  ASSERT.C
 *
 *  (C) Copyright 1997 by Autodesk, Inc.
 *
 *  This program is copyrighted by Autodesk, Inc. and is licensed to you under
 *  the following conditions.  You may not distribute or publish the source
 *  code of this program in any form.  You may incorporate this code in object
 *  form in derivative works provided such derivative works are (i.) are de-
 *  signed and intended to work solely with Autodesk, Inc. products, and (ii.)
 *  contain Autodesk's copyright notice "(C) Copyright 1995 by Autodesk, Inc."
 *
 *  AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.  AUTODESK SPE-
 *  CIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 *  A PARTICULAR USE.  AUTODESK, INC.  DOES NOT WARRANT THAT THE OPERATION OF
 *  THE PROGRAM WILL BE UNINTERRUPTED OR ERROR FREE.
 *
 ***************************************************************************/

#include <stdio.h>
#include <stdlib.h>


/* This function has two enhancements over the older asserts macro.  One, when an
   insertion fails, you can place a break point on the function and then back out
   to the calling routine, two, the assertion has a message attached that can later
   be converted to a run time error message */
void assertfunc(int ex, char *msg, char *file, int line)
{
   if(!(ex))
   {
      fprintf(stderr, "Assertion \"%s\" failed: file \"%s\", line %d\n", msg, file, line);
      exit(1);
   }
}
   

