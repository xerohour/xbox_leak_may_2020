/****************************************************************************
 *
 *  3DSKEY.C
 *
 *  (C) Copyright 1997 by Autodesk, Inc.
 *
 *  This program is copyrighted by Autodesk, Inc. and is licensed to you under
 *  the following conditions.  You may not distribute or publish the source
 *  code of this program in any form.  You may incorporate this code in object
 *  form in derivative works provided such derivative works are (i.) are de-
 *  signed and intended to work solely with Autodesk, Inc. products, and (ii.)
 *  contain Autodesk's copyright notice "(C) Copyright 1995 by Autodesk, Inc."
 *
 *  AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.  AUTODESK SPE-
 *  CIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 *  A PARTICULAR USE.  AUTODESK, INC.  DOES NOT WARRANT THAT THE OPERATION OF
 *  THE PROGRAM WILL BE UNINTERRUPTED OR ERROR FREE.
 *
 ***************************************************************************/

#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include "3dstype.h"
#include "3dsprim.h"
#include "3dserr.h"
#include "chunkinf.h"
#include "chunk3ds.h"
#include "3dsftkst.h"
#include "3dscamm.h"
#include "kfutils.h"
#include "3dskey.h"

/*------------------------------------------------------------
 | 
 | InitKeyInfo3ds
 | 
 +------------------------------------------------------------*/
void InitKeyInfo3ds(kfkeyinfo3ds *key)
{
  key->length = 30;
  key->curframe = 0;
}

void InitKfSegment3ds(kfsegment3ds *key)
{
  key->use = False3ds;
  key->begin = 0;
  key->end = 30;
}

void InitKfSets3ds(kfsets3ds **key)
{
  if (key == NULL) SET_ERROR_RETURN(ERR_INVALID_ARG);

  if (*key == NULL)
  {
    *key = malloc(sizeof(kfsets3ds));
    if (*key == NULL) SET_ERROR_RETURN(ERR_NO_MEM);
  }

  InitKeyInfo3ds(&((*key)->anim));
  InitKfSegment3ds(&((*key)->seg));
}

void ReleaseKfSets3ds(kfsets3ds **key)
{
  if (key != NULL)
  {
    free(*key);
    *key = NULL;
  }
}

void GetKeyInfo3ds(database3ds *db, kfkeyinfo3ds *key)
{
   chunk3ds *kfdata, *kfhdr, *kfcurtime;
   myassert(key != NULL, "GetKeyInfo3ds: arg *key cannot be NULL");

   kfGetKfSeg(db->topchunk, &kfdata);
   ON_ERROR_RETURN;

   FindNextChunk3ds(kfdata->children, KFHDR, &kfhdr);

   if (kfhdr != NULL)
   {
      KFHdr *d;
      
      d = ReadChunkData3ds(kfhdr);
      ON_ERROR_RETURN;

      key->length = d->animlength;

      FreeFileChunkData3ds(kfhdr);
   }

   FindNextChunk3ds(kfdata->children, KFCURTIME, &kfcurtime);

   if (kfcurtime != NULL)
   {
      KFCurtime *d;

      d = ReadChunkData3ds(kfcurtime);
      ON_ERROR_RETURN;

      key->curframe = d->currframenum;
   }
}

   
/*---------------------------------------------------------
 | PutKeyInfo
 |  Puts keyframe header information. Note:
 |   KeyframeHeader filename not handled in this
 |   version.         -sjw
 |
 +--------------------------------------------------------*/
void PutKeyInfo3ds(database3ds *db, kfkeyinfo3ds *key)
{
  chunk3ds *pChunk = NULL, *pKfChunk = NULL;
  KFHdr *hdata;
/*  KFSeg *fdata;  */
  KFCurtime *cdata;

  kfGetKfSeg(db->topchunk, &pKfChunk);
  ON_ERROR_RETURN;

  /*--- KEYFRAME HEADER */
  FindChunk3ds(pKfChunk, KFHDR, &pChunk);
  if (pChunk == NULL){ 
    InitChunk3ds(&pChunk); ON_ERROR_RETURN;
    pChunk->tag = KFHDR;
    hdata = InitChunkData3ds(pChunk);
    hdata->revision = 5; /*--- Default value */
    hdata->animlength = key->length;
    /*--- Filename Not Handled for now */
    hdata->filename = strdup("");
    AddChildOrdered3ds(pKfChunk, pChunk);ON_ERROR_RETURN;
  }
  else{
    hdata = ReadChunkData3ds(pChunk); ON_ERROR_RETURN;
    hdata->animlength = key->length;
  }

#ifdef DONT_DO
  /*--- KEYFRAME SEGMENT */
  pChunk = NULL;
  FindChunk3ds(pKfChunk, KFSEG, &pChunk);
  if (pChunk == NULL){ 
    InitChunk3ds(&pChunk); ON_ERROR_RETURN;
    pChunk->tag = KFSEG;
    fdata = InitChunkData3ds(pChunk);
    fdata->first = key->firstframe;
    fdata->last =  key->lastframe;
    AddChildOrdered3ds(pKfChunk, pChunk); ON_ERROR_RETURN;
  }
  else{
    fdata = ReadChunkData3ds(pChunk); ON_ERROR_RETURN;
    fdata->first = key->firstframe;
    fdata->last =  key->lastframe;
  }
#endif
  
  /*--- KEYFRAME CURTIME */ 
  pChunk = NULL;
  FindChunk3ds(pKfChunk, KFCURTIME, &pChunk);
  if (pChunk == NULL){ 
    InitChunk3ds(&pChunk); ON_ERROR_RETURN;
    pChunk->tag = KFCURTIME;
    cdata = InitChunkData3ds(pChunk);
    cdata->currframenum = key->curframe;
    AddChildOrdered3ds(pKfChunk, pChunk);
  }
  else {
    cdata = ReadChunkData3ds(pChunk); ON_ERROR_RETURN;
    cdata->currframenum = key->curframe;
  }
}

void GetKfSegment3ds(database3ds *db, kfsegment3ds *key)
{
   chunk3ds *kfdata, *kfseg;
   KFSeg *data;

   kfGetKfSeg(db->topchunk, &kfdata);

   FindNextChunk3ds(kfdata->children, KFSEG, &kfseg);
   if (kfseg != NULL)
   {
      data = ReadChunkData3ds(kfseg);
      ON_ERROR_RETURN;

      key->use = True3ds;
      key->begin = data->first;
      key->end = data->last;

      FreeFileChunkData3ds(kfseg);
   }
}
   

void PutKfSegment3ds(database3ds *db, kfsegment3ds *key)
{
  chunk3ds *kfdata, *kfseg;
  KFSeg *data;

  kfGetKfSeg(db->topchunk, &kfdata);

  if (key->use)
  {
    ReplaceOrAddChild3ds(kfdata, KFSEG, &kfseg);
    ON_ERROR_RETURN;
    
    data = InitChunkData3ds(kfseg);
    ON_ERROR_RETURN;
    
    data->first = key->begin;
    data->last = key->end;
  } else
  {
    FindNextChunk3ds(kfdata->children, KFSEG, &kfseg);
    DeleteChunk3ds(kfseg);
  }
}

void GetKfSets3ds(database3ds *db, kfsets3ds **key)
{
   kfsets3ds *k;
   
   if(db == NULL || key == NULL) SET_ERROR_RETURN(ERR_INVALID_ARG);
   if (db->topchunk == NULL) SET_ERROR_RETURN(ERR_INVALID_DATABASE);
   if ((db->topchunk->tag != M3DMAGIC) && (db->topchunk->tag != CMAGIC))
      SET_ERROR_RETURN(ERR_WRONG_DATABASE);

   InitKfSets3ds(key);
   ON_ERROR_RETURN;

   k = *key;
   
   GetKeyInfo3ds(db, &(k->anim));
   ON_ERROR_RETURN;

   GetKfSegment3ds(db, &(k->seg));
   ON_ERROR_RETURN;
}


void PutKfSets3ds(database3ds *db, kfsets3ds *key)
{
  if(db == NULL || key == NULL) 
    SET_ERROR_RETURN(ERR_INVALID_ARG);
  if (db->topchunk == NULL) SET_ERROR_RETURN(ERR_INVALID_DATABASE);
  if ((db->topchunk->tag != M3DMAGIC) && (db->topchunk->tag != CMAGIC))
     SET_ERROR_RETURN(ERR_WRONG_DATABASE);

  PutKeyInfo3ds(db, &(key->anim));
  ON_ERROR_RETURN;
  
  PutKfSegment3ds(db, &(key->seg));
  ON_ERROR_RETURN;
}

  
void CopyKfSets3ds(database3ds *destdb, database3ds *srcdb)
{
   chunk3ds *srckdata, *destkdata, *srcchunk, *destchunk;

   if ((destdb == NULL) || (srcdb == NULL))
      SET_ERROR_RETURN(ERR_INVALID_ARG);
   if ((srcdb->topchunk == NULL) || (destdb->topchunk == NULL))
      SET_ERROR_RETURN(ERR_INVALID_DATABASE);
   if ((srcdb->topchunk->tag != M3DMAGIC) && (srcdb->topchunk->tag != CMAGIC))
      SET_ERROR_RETURN(ERR_WRONG_DATABASE);
   if ((destdb->topchunk->tag != M3DMAGIC) && (destdb->topchunk->tag != CMAGIC))
      SET_ERROR_RETURN(ERR_WRONG_DATABASE);


   FindNextChunk3ds(srcdb->topchunk->children, KFDATA, &srckdata);

   if (srckdata != NULL)
   {
      
      kfGetKfSeg(destdb->topchunk, &destkdata);
      ON_ERROR_RETURN;

      FindNextChunk3ds(srckdata, KFHDR, &srcchunk);

      if (srcchunk != NULL)
      {
	 FindNextChunk3ds(destkdata->children, srcchunk->tag, &destchunk);

	 if (destchunk != NULL) DeleteChunk3ds(destchunk);

	 CopyChunk3ds(srcchunk, &destchunk);
	 ON_ERROR_RETURN;

	 AddChildOrdered3ds(destkdata, destchunk);

      }

      FindNextChunk3ds(srckdata, KFCURTIME, &srcchunk);

      if (srcchunk != NULL)
      {
	 FindNextChunk3ds(destkdata->children, srcchunk->tag, &destchunk);

	 if (destchunk != NULL) DeleteChunk3ds(destchunk);

	 CopyChunk3ds(srcchunk, &destchunk);
	 ON_ERROR_RETURN;

	 AddChildOrdered3ds(destkdata, destchunk);

      }

      FindNextChunk3ds(srckdata, KFSEG, &srcchunk);

      if (srcchunk != NULL)
      {
	 FindNextChunk3ds(destkdata->children, srcchunk->tag, &destchunk);

	 if (destchunk != NULL) DeleteChunk3ds(destchunk);

	 CopyChunk3ds(srcchunk, &destchunk);
	 ON_ERROR_RETURN;

	 AddChildOrdered3ds(destkdata, destchunk);

      }

   }
}

	 
