/****************************************************************************
 *
 *  3DSIOBJ.C
 *
 *  (C) Copyright 1997 by Autodesk, Inc.
 *
 *  This program is copyrighted by Autodesk, Inc. and is licensed to you under
 *  the following conditions.  You may not distribute or publish the source
 *  code of this program in any form.  You may incorporate this code in object
 *  form in derivative works provided such derivative works are (i.) are de-
 *  signed and intended to work solely with Autodesk, Inc. products, and (ii.)
 *  contain Autodesk's copyright notice "(C) Copyright 1995 by Autodesk, Inc."
 *
 *  AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.  AUTODESK SPE-
 *  CIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 *  A PARTICULAR USE.  AUTODESK, INC.  DOES NOT WARRANT THAT THE OPERATION OF
 *  THE PROGRAM WILL BE UNINTERRUPTED OR ERROR FREE.
 *
 ***************************************************************************/

#include <malloc.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "3dstype.h"
#include "3dserr.h"
#include "3dsmobj.h"
#include "3dsrobj.h"
#include "3dsiobj.h"

static const objmat3ds DefObjMat3ds = {{0}, 0, NULL};

void InitMeshObjField3ds (mesh3ds *obj, const ushort3ds field)
{
   ulong3ds i;
   void *tpnt;
   
   if (obj == NULL)
      SET_ERROR_RETURN(ERR_INVALID_ARG);

   /* Test to see if vertices are being allocated */
   if ((field & InitVertexArray3ds) == InitVertexArray3ds)
   {
      if (obj->nvertices == 0) /* If the vertice count is 0 then free the array */
      {
	 RelMeshObjField3ds(obj, RelVertexArray3ds);
      } else 
      {
	 if (obj->vertexarray == NULL) /* if this is the very first allocation */
	 {
	    /* Allocate the new block of memory */
	    obj->vertexarray = calloc(obj->nvertices, sizeof(point3ds));
	    if (obj->vertexarray == NULL) SET_ERROR_RETURN(ERR_NO_MEM);

	    /* Initialize the new block */
	    for (i = 0; i < obj->nvertices; i++)
	       memcpy(&((obj->vertexarray)[i]), &DefPoint3ds, sizeof(DefPoint3ds));
	 } else /* else this is an existing block */
	 {
	    /* Just resize it */
	    tpnt = realloc(obj->vertexarray, sizeof(point3ds)*obj->nvertices);
	    if (tpnt == NULL) SET_ERROR_RETURN(ERR_NO_MEM);

	    /* Dont set the new pointer unless the allocation was successful */
	    obj->vertexarray = tpnt;
	 }
      }
   }
   
   if ((field & InitTextArray3ds) == InitTextArray3ds)
   {
      if (obj->ntextverts == 0)
      {
	 RelMeshObjField3ds(obj, RelTextArray3ds);
      } else 
      {
	 if (obj->textarray == NULL)
	 {
	    obj->textarray = calloc(obj->ntextverts, sizeof(textvert3ds));
	    if (obj->textarray == NULL) SET_ERROR_RETURN(ERR_NO_MEM);
	    
	    for (i = 0; i < obj->ntextverts; i++)
	       memcpy(&((obj->textarray)[i]), &DefTextVert3ds, sizeof(DefTextVert3ds));
	 } else
	 {
	    tpnt = realloc(obj->textarray, sizeof(textvert3ds)*obj->ntextverts);
	    if (tpnt == NULL) SET_ERROR_RETURN(ERR_NO_MEM);

	    obj->textarray = tpnt;
	 }
      }
   }
   
   if ((field & InitFaceArray3ds) == InitFaceArray3ds)
   {
      if (obj->nfaces == 0)
      {
	 RelMeshObjField3ds(obj, RelFaceArray3ds);
      } else
      {
	 if (obj->facearray == NULL)
	 {
	    obj->facearray = calloc(obj->nfaces, sizeof(face3ds));
	    if (obj->facearray == NULL) SET_ERROR_RETURN(ERR_NO_MEM);

	    for (i = 0; i < obj->nfaces; i++)
	       memcpy(&((obj->facearray)[i]), &DefFace3ds, sizeof(DefFace3ds));
	 } else
	 {
	    tpnt = realloc(obj->facearray, sizeof(face3ds)*obj->nfaces);
	    if (tpnt == NULL) SET_ERROR_RETURN(ERR_NO_MEM);

	    obj->facearray = tpnt;
	 }
      }
   }
   
   if ((field & InitMatArray3ds) == InitMatArray3ds)
   {
      if (obj->nmats == 0)
      {
	 RelMeshObjField3ds(obj, RelMatArray3ds);
      } else
      {
	 if (obj->matarray == NULL)
	 {
	    obj->matarray = calloc(obj->nmats, sizeof(objmat3ds));
	    if (obj->matarray == NULL) SET_ERROR_RETURN(ERR_NO_MEM);
	    
	    for (i = 0; i < obj->nmats; i++)
	       memcpy(&((obj->matarray)[i]), &DefObjMat3ds, sizeof(DefObjMat3ds));
	 } else
	 {
	    tpnt = realloc(obj->matarray, sizeof(objmat3ds)*obj->nmats);
	    if (tpnt == NULL) SET_ERROR_RETURN(ERR_NO_MEM);

	    obj->matarray = tpnt;
	 }
      }
   }
   
   if ((field & InitSmoothArray3ds) == InitSmoothArray3ds)
   {
      if (obj->nfaces == 0)
      {
	 RelMeshObjField3ds(obj, RelSmoothArray3ds);
      } else
      {
	 if (obj->smootharray == NULL)
	 {
	    obj->smootharray = calloc(obj->nfaces, sizeof(ulong3ds));
	    if (obj->smootharray == NULL) SET_ERROR_RETURN(ERR_NO_MEM);

	    for (i = 0; i < obj->nfaces; i++)
	       (obj->smootharray)[i] = 0;
	 } else
	 {
	    tpnt = realloc(obj->smootharray, sizeof(ulong3ds)*obj->nfaces);
	    if (tpnt == NULL) SET_ERROR_RETURN(ERR_NO_MEM);

	    obj->smootharray = tpnt;
	 }
      }
   }
   
   if ((field & InitProcData3ds) == InitProcData3ds)
   {
      if (obj->procsize == 0)
      {
	 RelMeshObjField3ds(obj, RelProcData3ds);
      } else
      {
	 if (obj->procdata == NULL)
	 {
	    obj->procdata = calloc(obj->procsize, sizeof(ubyte3ds));
	    if (obj->procdata == NULL) SET_ERROR_RETURN(ERR_NO_MEM);

	    memset(obj->procdata, 0, sizeof(ubyte3ds)*obj->procsize);
	 } else
	 {
	    tpnt = realloc(obj->procdata, sizeof(ubyte3ds)*obj->procsize);
	    if (tpnt == NULL) SET_ERROR_RETURN(ERR_NO_MEM);

	    obj->procdata = tpnt;
	 }
      }
   }
   
   if ((field & InitVFlagArray3ds) == InitVFlagArray3ds)
   {
      if (obj->nvertices == 0)
      {
	 RelMeshObjField3ds(obj, RelVFlagArray3ds);
      } else
      {
	 if (obj->vflagarray == NULL)
	 {
	    obj->vflagarray = calloc(obj->nvertices, sizeof(ushort3ds));
	    if (obj->vflagarray == NULL) SET_ERROR_RETURN(ERR_NO_MEM);
	    
	    for (i = 0; i < obj->nvflags; i++) obj->vflagarray[i] = 0;
	 } else
	 {
	    tpnt = realloc(obj->vflagarray, sizeof(ushort3ds)*obj->nvertices);
	    if (tpnt == NULL) SET_ERROR_RETURN(ERR_NO_MEM);
	    
	    obj->vflagarray = tpnt;
	 }
      }
   }
   
}

void InitMatArrayIndex3ds (mesh3ds *obj, ushort3ds mat, ushort3ds nfaces)
{
  if (obj == NULL || nfaces == 0)
    SET_ERROR_RETURN(ERR_INVALID_ARG);

  if (obj->nfaces == 0 || mat > obj->nmats)
    SET_ERROR_RETURN(ERR_INVALID_DATA);

  if (obj->matarray[mat].faceindex)
    free(obj->matarray[mat].faceindex);

  obj->matarray[mat].faceindex = calloc(nfaces, sizeof(ushort3ds));
  if (obj->matarray[mat].faceindex == NULL)
    SET_ERROR_RETURN(ERR_NO_MEM);
}

void InitMeshObj3ds(mesh3ds **obj, ushort3ds nvertices, ushort3ds nfaces, ushort3ds initflags)
{
   ulong3ds i;
   mesh3ds *mobj;

   if (obj == NULL) SET_ERROR_RETURN(ERR_INVALID_ARG);

   mobj = *obj; /* Some compilers generate wasteful dereferencing code for each occurance if this isn't done */
   
   if (mobj == NULL)
   {
      mobj = malloc(sizeof(mesh3ds));
      if (mobj == NULL) SET_ERROR_RETURN(ERR_NO_MEM);

      *obj = mobj;
      
      mobj->vertexarray = NULL;
      mobj->textarray = NULL;
      mobj->vflagarray = NULL;
      mobj->facearray = NULL;
      mobj->matarray = NULL;
      mobj->smootharray = NULL;
      mobj->procdata = NULL;
   }
   
   mobj->name[0] = 0;
   mobj->ishidden = False3ds;
   mobj->isvislofter = False3ds;
   mobj->ismatte = False3ds;
   mobj->isnocast = False3ds;
   mobj->isnorcvshad = False3ds;
   mobj->isfast = False3ds;
   mobj->isfrozen = False3ds;
   mobj->nvertices = nvertices;
   mobj->ntextverts = 0;
   mobj->nvflags = 0;

   mobj->usemapinfo = False3ds;
   mobj->map.maptype = 0;
   mobj->map.tilex = 1.0F;
   mobj->map.tiley = 1.0F;
   mobj->map.cenx = 0.0F;
   mobj->map.ceny = 0.0F;
   mobj->map.cenz = 0.0F;
   mobj->map.scale = 1.0F;
   mobj->map.matrix[0] = 1.0F;
   mobj->map.matrix[1] = 0.0F;
   mobj->map.matrix[2] = 0.0F;
   mobj->map.matrix[3] = 0.0F;
   mobj->map.matrix[4] = 1.0F;
   mobj->map.matrix[5] = 0.0F;
   mobj->map.matrix[6] = 0.0F;
   mobj->map.matrix[7] = 0.0F;
   mobj->map.matrix[8] = 0.0F;
   mobj->map.matrix[9] = 0.0F;
   mobj->map.matrix[10] = 0.0F;
   mobj->map.matrix[11] = 0.0F;
   mobj->map.pw = 1.0F;
   mobj->map.ph = 1.0F;
   mobj->map.ch = 1.0F;

   for (i = 0; i < 12; i++) mobj->locmatrix[i] = 0.0F;
   mobj->nfaces = nfaces;
   mobj->nmats = 0;
   mobj->useboxmap = False3ds;
   for (i = 0; i < 6; i++) mobj->boxmap[i][0] = 0;
   mobj->meshcolor = 0;
   mobj->procsize = 0;
   mobj->procname[0] = 0;
   
   InitMeshObjField3ds(mobj, (ushort3ds)(InitVertexArray3ds | InitFaceArray3ds));
   ON_ERROR_RETURN;
   
   if ((initflags & InitTextArray3ds) == InitTextArray3ds)
   {
      mobj->ntextverts = mobj->nvertices;
      InitMeshObjField3ds(mobj, InitTextArray3ds);
      ON_ERROR_RETURN;
   }

   if ((initflags & InitVFlagArray3ds) == InitVFlagArray3ds)
   {
      mobj->nvflags = mobj->nvertices;
      InitMeshObjField3ds(mobj, InitVFlagArray3ds);
      ON_ERROR_RETURN;
   }

   if ((initflags & InitSmoothArray3ds) == InitSmoothArray3ds)
   {
      InitMeshObjField3ds(mobj, InitSmoothArray3ds);
      ON_ERROR_RETURN;
   }
   return;
   
}
