/****************************************************************************
 *
 *  3DSSTRLF.C
 *
 *  (C) Copyright 1997 by Autodesk, Inc.
 *
 *  This program is copyrighted by Autodesk, Inc. and is licensed to you under
 *  the following conditions.  You may not distribute or publish the source
 *  code of this program in any form.  You may incorporate this code in object
 *  form in derivative works provided such derivative works are (i.) are de-
 *  signed and intended to work solely with Autodesk, Inc. products, and (ii.)
 *  contain Autodesk's copyright notice "(C) Copyright 1995 by Autodesk, Inc."
 *
 *  AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.  AUTODESK SPE-
 *  CIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 *  A PARTICULAR USE.  AUTODESK, INC.  DOES NOT WARRANT THAT THE OPERATION OF
 *  THE PROGRAM WILL BE UNINTERRUPTED OR ERROR FREE.
 *
 ***************************************************************************/

/* A string length scanner that has an upper limit */

#include <stdio.h>
#include <assert.h>
#include "3dstype.h"
#include "3dserr.h"
#include "3dsstrlf.h"


/* maxlength is increased by one to account for a null character*/
ulong3ds strlenf3ds(const char3ds *string, long3ds maxlength)
{
   long3ds i;

   if (string == NULL)
     SET_ERROR_RETURNR(ERR_INVALID_ARG, 0);

   if (string == NULL) return 0;

   for (i = 0; i < (maxlength+1); i++)
   {
      if (string[i] == 0) break;
   }
   if (string[i] != 0)
     SET_ERROR_RETURNR(ERR_STRING_TOO_LONG, 0);

   return(i);
}


