/****************************************************************************
 *
 *  3DSMATX.C
 *
 *  (C) Copyright 1997 by Autodesk, Inc.
 *
 *  This program is copyrighted by Autodesk, Inc. and is licensed to you under
 *  the following conditions.  You may not distribute or publish the source
 *  code of this program in any form.  You may incorporate this code in object
 *  form in derivative works provided such derivative works are (i.) are de-
 *  signed and intended to work solely with Autodesk, Inc. products, and (ii.)
 *  contain Autodesk's copyright notice "(C) Copyright 1995 by Autodesk, Inc."
 *
 *  AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.  AUTODESK SPE-
 *  CIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 *  A PARTICULAR USE.  AUTODESK, INC.  DOES NOT WARRANT THAT THE OPERATION OF
 *  THE PROGRAM WILL BE UNINTERRUPTED OR ERROR FREE.
 *
 ***************************************************************************/

#include <math.h>
#include <malloc.h>
#include <stdlib.h>
#include "3dstype.h"
#include "3dserr.h"
#include "chunk3ds.h"
#include "3dsprim.h"
#include "3dsmobj.h"
#include "3dsmatx.h"

void FillMatrix3ds(mesh3ds *obj)
{
   ushort3ds i;
   point3ds min,max;

   if (obj == NULL) SET_ERROR_RETURN(ERR_INVALID_ARG);
   if ((obj->nvertices == 0) || (obj->vertexarray == NULL)) SET_ERROR_RETURN(ERR_INVALID_DATA);

   min.x = max.x = obj->vertexarray[0].x;
   min.y = max.y = obj->vertexarray[0].y;
   min.z = max.z = obj->vertexarray[0].z;
   for (i=1;i<obj->nvertices;i++) {
      if (obj->vertexarray[i].x < min.x)
         min.x = obj->vertexarray[i].x;
      if (obj->vertexarray[i].y < min.y)
         min.y = obj->vertexarray[i].y;
      if (obj->vertexarray[i].z < min.z)
         min.z = obj->vertexarray[i].z;
      if (obj->vertexarray[i].x > max.x)
         max.x = obj->vertexarray[i].x;
      if (obj->vertexarray[i].y > max.y)
         max.y = obj->vertexarray[i].y;
      if (obj->vertexarray[i].z > max.z)
         max.z = obj->vertexarray[i].z;
   }
   obj->locmatrix[0] = 1.0F;
   obj->locmatrix[1] = 0.0F;
   obj->locmatrix[2] = 0.0F;
   obj->locmatrix[3] = 0.0F;
   obj->locmatrix[4] = 1.0F;
   obj->locmatrix[5] = 0.0F;
   obj->locmatrix[6] = 0.0F;
   obj->locmatrix[7] = 0.0F;
   obj->locmatrix[8] = 1.0F;
   obj->locmatrix[9] = (max.x+min.x)*0.5F;
   obj->locmatrix[10] = (max.y+min.y)*0.5F;
   obj->locmatrix[11] = (max.z+min.z)*0.5F;
}

