/****************************************************************************
 *
 *  STRCMPI.C
 *
 *  (C) Copyright 1997 by Autodesk, Inc.
 *
 *  This program is copyrighted by Autodesk, Inc. and is licensed to you under
 *  the following conditions.  You may not distribute or publish the source
 *  code of this program in any form.  You may incorporate this code in object
 *  form in derivative works provided such derivative works are (i.) are de-
 *  signed and intended to work solely with Autodesk, Inc. products, and (ii.)
 *  contain Autodesk's copyright notice "(C) Copyright 1995 by Autodesk, Inc."
 *
 *  AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.  AUTODESK SPE-
 *  CIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 *  A PARTICULAR USE.  AUTODESK, INC.  DOES NOT WARRANT THAT THE OPERATION OF
 *  THE PROGRAM WILL BE UNINTERRUPTED OR ERROR FREE.
 *
 ***************************************************************************/

/* A home brew case insensitive string compare for those few platforms that
   don't have them in thier standard libraries.
*/

#include <ctype.h>
#include "3dstype.h"
#include "strcmpi.h"

int strcmpi(char3ds *s1, char3ds *s2)
{
   char3ds *a1, *a2, c1, c2;
   a1 = s1;
   a2 = s2;

   for (;;)
   {
      c1 = (char3ds)tolower(*a1); c2 = (char3ds)tolower(*a2);
      if ((c1 == 0) && (c2 == 0)) return(0);
      if (c1 < c2) return(-1);
      if (c1 > c2) return(1);
      a1++; a2++;
   }
}
