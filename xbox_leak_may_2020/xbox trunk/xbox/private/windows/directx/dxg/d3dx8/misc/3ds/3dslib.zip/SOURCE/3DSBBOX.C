/****************************************************************************
 *
 *  3DSBBOX.C
 *
 *  (C) Copyright 1997 by Autodesk, Inc.
 *
 *  This program is copyrighted by Autodesk, Inc. and is licensed to you under
 *  the following conditions.  You may not distribute or publish the source
 *  code of this program in any form.  You may incorporate this code in object
 *  form in derivative works provided such derivative works are (i.) are de-
 *  signed and intended to work solely with Autodesk, Inc. products, and (ii.)
 *  contain Autodesk's copyright notice "(C) Copyright 1995 by Autodesk, Inc."
 *
 *  AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.  AUTODESK SPE-
 *  CIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 *  A PARTICULAR USE.  AUTODESK, INC.  DOES NOT WARRANT THAT THE OPERATION OF
 *  THE PROGRAM WILL BE UNINTERRUPTED OR ERROR FREE.
 *
 ***************************************************************************/

#include <malloc.h>
#include <stdlib.h>
#include "3dstype.h"
#include "3dserr.h"
#include "chunk3ds.h"
#include "3dsmobj.h"
#include "3dsobjm.h"
#include "3dsbbox.h"

void SetBoundBox3ds(const mesh3ds *mobj, kfmesh3ds *kobj )
{
   ushort3ds i;

   if((mobj == NULL) || (kobj == NULL))
     SET_ERROR_RETURN(ERR_INVALID_ARG);

   if((mobj->vertexarray == NULL) || (mobj->nvertices == 0))
     SET_ERROR_RETURN(ERR_INVALID_DATA);

   kobj->boundmin.x = kobj->boundmax.x = mobj->vertexarray[0].x;
   kobj->boundmin.y = kobj->boundmax.y = mobj->vertexarray[0].y;
   kobj->boundmin.z = kobj->boundmax.z = mobj->vertexarray[0].z;

   for (i=1; i<mobj->nvertices; i++) {
      if( mobj->vertexarray[i].x < kobj->boundmin.x )
         kobj->boundmin.x = mobj->vertexarray[i].x;
      if( mobj->vertexarray[i].y < kobj->boundmin.y )
         kobj->boundmin.y = mobj->vertexarray[i].y;
      if( mobj->vertexarray[i].z < kobj->boundmin.z )
         kobj->boundmin.z = mobj->vertexarray[i].z;

      if( mobj->vertexarray[i].x > kobj->boundmax.x )
         kobj->boundmax.x = mobj->vertexarray[i].x;
      if( mobj->vertexarray[i].y > kobj->boundmax.y )
         kobj->boundmax.y = mobj->vertexarray[i].y;
      if( mobj->vertexarray[i].z > kobj->boundmax.z )
         kobj->boundmax.z = mobj->vertexarray[i].z;
   }
}
