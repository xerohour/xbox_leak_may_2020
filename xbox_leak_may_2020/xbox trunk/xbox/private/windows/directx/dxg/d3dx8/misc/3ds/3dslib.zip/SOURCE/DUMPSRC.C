/****************************************************************************
 *
 *  DUMPSRC.C
 *
 *  (C) Copyright 1997 by Autodesk, Inc.
 *
 *  This program is copyrighted by Autodesk, Inc. and is licensed to you under
 *  the following conditions.  You may not distribute or publish the source
 *  code of this program in any form.  You may incorporate this code in object
 *  form in derivative works provided such derivative works are (i.) are de-
 *  signed and intended to work solely with Autodesk, Inc. products, and (ii.)
 *  contain Autodesk's copyright notice "(C) Copyright 1995 by Autodesk, Inc."
 *
 *  AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.  AUTODESK SPE-
 *  CIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 *  A PARTICULAR USE.  AUTODESK, INC.  DOES NOT WARRANT THAT THE OPERATION OF
 *  THE PROGRAM WILL BE UNINTERRUPTED OR ERROR FREE.
 *
 ***************************************************************************/

/* Source file for DumpScr3ds functions for emiting source reps of structures */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "3dstype.h"
#include "3dserr.h"
#include "3dsmobj.h"
#include "3dsmatr.h"
#include "dumpsrc.h"

void DumpMeshSrc3ds(FILE *out, const mesh3ds *mesh, const char3ds *varname)
{
   ushort3ds i,j;
   
   if (out == NULL || mesh == NULL)
     SET_ERROR_RETURN(ERR_INVALID_ARG);

   if (mesh->vertexarray != NULL)
   {
      fprintf(out, "point3ds %sverts[%i] = {", varname, mesh->nvertices);
      for (i = 0; i < mesh->nvertices; i++)
      {
	 if (i > 0) fprintf(out, ", ");
	 if ((i % 2) == 0) fprintf(out, "\n   ");
	 fprintf(out, "{%f, %f, %f}", mesh->vertexarray[i].x, mesh->vertexarray[i].y, mesh->vertexarray[i].z);
      }
      fprintf(out, "\n};\n\n");
   }

   if (mesh->textarray != NULL)
   {
      fprintf(out, "textvert3ds %stext[%i] = {", varname, mesh->ntextverts);
      for (i = 0; i < mesh->ntextverts; i++)
      {
	 if (i > 0) fprintf(out, ", ");
	 if ((i % 3) == 0) fprintf(out, "\n   ");
	 fprintf(out, "{%f, %f}", mesh->textarray[i].u, mesh->textarray[i].v);
      }
      fprintf(out, "\n};\n\n");
   }

   if (mesh->facearray != NULL)
   {
      fprintf(out, "face3ds %sface[%i] = {", varname, mesh->nfaces);
      for (i = 0; i < mesh->nfaces; i++)
      {
	 if (i > 0) fprintf(out, ", ");
	 if ((i % 2) == 0) fprintf(out, "\n   ");
	 fprintf(out, "{%i, %i, %i, 0x%x}", mesh->facearray[i].v1, mesh->facearray[i].v2, mesh->facearray[i].v3, mesh->facearray[i].flag);
      }
      fprintf(out, "\n};\n\n");
   }
   if (mesh->smootharray != NULL)
   {
      fprintf(out, "ulong3ds %ssmooth[%i] = {", varname, mesh->nfaces);
      for (i = 0; i < mesh->nfaces; i++)
      {
	 if (i > 0) fprintf(out, ", ");
	 if ((i % 4) == 0) fprintf(out, "\n   ");
	 fprintf(out, "0x%x", mesh->smootharray[i]);
      }
      fprintf(out, "\n};\n\n");
   }

   if (mesh->matarray != NULL)
   {
      for (i = 0; i < mesh->nmats; i++)
      {
	 if (mesh->matarray[i].faceindex != NULL)
	 {
	    fprintf(out, "ushort3ds %sfal%i[%i] = {", varname, i, mesh->matarray[i].nfaces);
	    for (j = 0; j < mesh->matarray[i].nfaces; j++)
	    {
	       if (j > 0) fprintf(out, ", ");
	       if ((j % 6) == 0) fprintf(out, "\n   ");
	       fprintf(out, "%u", mesh->matarray[i].faceindex[j]);
	    }
	    fprintf(out, "\n};\n\n");
	 }
      }

      fprintf(out, "objmat3ds %smats[%i] = {\n", varname, mesh->nmats);
      for (i = 0; i < mesh->nmats; i++)
      {
	 fprintf(out, "   {\"%s\", %i, ", mesh->matarray[i].name, mesh->matarray[i].nfaces);
	 fprintf(out, "%sfal%i}\n", varname, i);
      }
      fprintf(out, "\n};\n\n");
   }
   
   fprintf(out, "mesh3ds %s = {\n", varname);

   i = (ushort3ds)strlen(varname);
   fprintf(out, "   {");
   for (j = 0; j < i; j++)
   {
      if (j > 0) fprintf(out, ",");
      fprintf(out, "'%c'", varname[j]);
   }
   fprintf(out, "}, /* name */\n");

   fprintf(out, "   %u, /* ishidden */\n", mesh->ishidden);
   fprintf(out, "   %u, /* isvislofter */\n", mesh->isvislofter);
   fprintf(out, "   %u, /* ismatte */\n", mesh->ismatte);
   fprintf(out, "   %u, /* isnocast */\n", mesh->isnocast);
   fprintf(out, "   %u, /* isfast */\n", mesh->isfast);
   fprintf(out, "   %u, /* isnorcvshad */\n", mesh->isnorcvshad);
   fprintf(out, "   %u, /* isfrozen */\n", mesh->isfrozen);

   fprintf(out, "   %i, /* nvertices */\n", mesh->nvertices);

   if (mesh->vertexarray != NULL)
      fprintf(out, "   %sverts, /* vertexarray */\n", varname);
   else
      fprintf(out, "   NULL, /* vertexarray */\n");

   fprintf(out, "   %i, /* ntextverts */\n", mesh->ntextverts);

   if (mesh->textarray != NULL)
      fprintf(out, "   %stexts, /* textarray */\n", varname);
   else
      fprintf(out, "   NULL, /* textarray */\n");
   
   fprintf(out, "   %u, /* usemapinfo */\n", mesh->usemapinfo);
   
   fprintf(out, "   { /* map */\n");
   fprintf(out, "      %i, /* map.maptype */\n", mesh->map.maptype);
   fprintf(out, "      %f, /* map.tilex */\n", mesh->map.tilex);
   fprintf(out, "      %f, /* map.tiley */\n", mesh->map.tiley);
   fprintf(out, "      %f, /* map.cenx */\n", mesh->map.cenx);
   fprintf(out, "      %f, /* map.ceny */\n", mesh->map.ceny);
   fprintf(out, "      %f, /* map.cenz */\n", mesh->map.cenz);
   fprintf(out, "      %f, /* map.scale */\n", mesh->map.scale);
   fprintf(out, "      { /* map.matrix[12] */");
   for (i = 0; i < 12; i++)
   {
      if ((i % 4) == 0) fprintf(out, "\n         ");
      fprintf(out, "%f, ", mesh->map.matrix[i]);
   }
   fprintf(out, "\n      },\n");
   fprintf(out, "      %f, /* map.pw */\n", mesh->map.pw);   
   fprintf(out, "      %f, /* map.ph */\n", mesh->map.ph);
   fprintf(out, "      %f, /* map.ch */\n", mesh->map.ch);
   fprintf(out, "   },\n");
   fprintf(out, "   { /* locmatrix[12] */");
   for (i = 0; i < 12; i++)
   {
      if ((i % 4) == 0) fprintf(out, "\n      ");
      fprintf(out, "%f, ", mesh->locmatrix[i]);
   }
   fprintf(out, "\n   },\n");
   fprintf(out, "   %i, /* nfaces */\n", mesh->nfaces);
   if (mesh->facearray != NULL)
      fprintf(out, "   %sface, /* facearray */\n", varname);
   else
      fprintf(out, "   NULL, /* facearray */\n");
   if (mesh->smootharray != NULL)
      fprintf(out, "   %ssmooth, /* smootharray */\n", varname);
   else
      fprintf(out, "   NULL, /* smootharray */\n");

   fprintf(out, "   %u, /* useboxmap */\n", mesh->useboxmap);
   fprintf(out, "   { /* boxmap */\n");
   for (i = 0; i < 6; i++)
   {
      if (mesh->boxmap[i][0] == 0)
	 fprintf(out, "      \"\",\n");
      else
	 fprintf(out, "      \"%s\",\n", mesh->boxmap[i]);
   }
   fprintf(out, "   },\n");
   fprintf(out, "   %i, /* meshcolor */\n", mesh->meshcolor);
   fprintf(out, "   %i, /* nmats */\n", mesh->nmats);
   if (mesh->matarray != NULL)
      fprintf(out, "   %smats, /* matarray */\n", varname);
   else
      fprintf(out, "   NULL, /* matarray */\n");

   fprintf(out, "   %i, /* procsize */\n", mesh->procsize);
   fprintf(out, "   \"%s\", /* procname */\n", mesh->procname);
   if (mesh->procdata != NULL)
      fprintf(out, "   %sproc /* procdata */\n", varname);
   else
      fprintf(out, "   NULL /* procdata */\n");
   fprintf(out, "};\n");
}

