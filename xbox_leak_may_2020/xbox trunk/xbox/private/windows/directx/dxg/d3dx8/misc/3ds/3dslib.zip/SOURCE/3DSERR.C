/****************************************************************************
 *
 *  3DSERR.C
 *
 *  (C) Copyright 1997 by Autodesk, Inc.
 *
 *  This program is copyrighted by Autodesk, Inc. and is licensed to you under
 *  the following conditions.  You may not distribute or publish the source
 *  code of this program in any form.  You may incorporate this code in object
 *  form in derivative works provided such derivative works are (i.) are de-
 *  signed and intended to work solely with Autodesk, Inc. products, and (ii.)
 *  contain Autodesk's copyright notice "(C) Copyright 1995 by Autodesk, Inc."
 *
 *  AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.  AUTODESK SPE-
 *  CIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 *  A PARTICULAR USE.  AUTODESK, INC.  DOES NOT WARRANT THAT THE OPERATION OF
 *  THE PROGRAM WILL BE UNINTERRUPTED OR ERROR FREE.
 *
 ***************************************************************************/

#include <stdio.h>

#include "3dstype.h"
#include "3dsprim.h"
#include "3dserr.h"

#define ERR_STACK_ENTRIES 20

#define ERR_STACK_INIT {NO_FTK_ERRORS, NULL}

/* The extra entry is always set to NO_FTK_ERRORS so we always know were the end is */
static ErrRec3ds ErrStack[ERR_STACK_ENTRIES+1] = {ERR_STACK_INIT, ERR_STACK_INIT, ERR_STACK_INIT, ERR_STACK_INIT, ERR_STACK_INIT, ERR_STACK_INIT, ERR_STACK_INIT, ERR_STACK_INIT, ERR_STACK_INIT, ERR_STACK_INIT, ERR_STACK_INIT, ERR_STACK_INIT, ERR_STACK_INIT, ERR_STACK_INIT, ERR_STACK_INIT, ERR_STACK_INIT, ERR_STACK_INIT, ERR_STACK_INIT, ERR_STACK_INIT, ERR_STACK_INIT, ERR_STACK_INIT};

/*--- Global Error Flags */
byte3ds ftkerr3ds = FALSE3DS, ignoreftkerr3ds = FALSE3DS;

void PushErrList3ds(errorid3ds id)
{
   int i = 0;

   if (id == NO_FTK_ERRORS) return;

   ftkerr3ds = True3ds;
   
   for (i = 0; i < (ERR_STACK_ENTRIES-1); i++)
   {
      if (ErrStack[i].id == NO_FTK_ERRORS)
      {
	 ErrStack[i].id = id;
	 ErrStack[i].desc = ErrCodeToString3ds(id);
	 ErrStack[i+1].id = NO_FTK_ERRORS;
	 return;
      }
   }
   /* If loop completed, then ERR_STACK_ENTRIES of errors has occured */
   if (ErrStack[ERR_STACK_ENTRIES].id == NO_FTK_ERRORS) /* If the last slot is empty */
   {
      ErrStack[ERR_STACK_ENTRIES].id = id; /* Fill the last slot with a valid error */
      ErrStack[ERR_STACK_ENTRIES].desc = ErrCodeToString3ds(id);
   } else /* Set the last error to max error warning */
   {
      ErrStack[ERR_STACK_ENTRIES].id = N_ERRORS;
      ErrStack[ERR_STACK_ENTRIES].desc = ErrCodeToString3ds(N_ERRORS);
   }
}

void ClearErrList3ds()
{
  int i;

  ftkerr3ds = False3ds;

  for (i=0; i<ERR_STACK_ENTRIES; i++)
    ErrStack[i].id = FTK_NO_ERROR;
}

void DumpErrList3ds(FILE *outfile)
{
  int i = ERR_STACK_ENTRIES;

  while(i){
    if (ErrStack[i-1].id != FTK_NO_ERROR)
      fprintf(outfile, "%s\n", ErrStack[i-1].desc);
    i--;
  }
}     

const ErrRec3ds *ReturnErrorList3ds()
{
   return (const ErrRec3ds *)(&ErrStack);
}

const char3ds *ErrCodeToString3ds(errorid3ds err)
{
   switch(err)
   {
   case NO_FTK_ERRORS:
      return("NO_FTK_ERRORS: No errors are pending");
   case ERR_NO_MEM:
      return("ERR_NO_MEM: Not enough memory to complete operation");
   case ERR_INVALID_ARG:
      return("ERR_INVALID_ARG: The argument passed to the function is invalid.  Usually caused by a NULL pointer or an out of range numeric argument.");
   case ERR_INVALID_DATA:
      return("ERR_INVALID_DATA: The structure passed as an argument to the function has invalid or out of range data in its fields.");
   case ERR_INVALID_CHUNK:
      return("ERR_INVALID_CHUNK: An invalid chunk structure was encountered while reading the database. Usually caused by a corrupt database or file");
   case ERR_INVALID_DATABASE:
      return("ERR_INVALID_DATABASE: The database passed as an argument has not be created yet.");
   case ERR_WRONG_DATABASE:
      return("ERR_WRONG_DATABASE: The database passed as an argument is the wrong kind of database for this function.");
   case ERR_UNFOUND_CHUNK:
      return("ERR_UNFOUND_CHUNK: The database is missing important file chunks needed to fill out the requested structure.  Usually caused by a corrupt database or file");
   case ERR_WRONG_OBJECT:
      return("ERR_WRONG_OBJECT: The name passed to the functions exists, but is not the type of object asked for.  For example, asking for a mesh object with the GetCameraByName3ds function.");
   case ERR_NO_SUCH_FILE:
      return("ERR_NO_SUCH_FILE: The filename passed as an argument for reading does not exist");
   case ERR_INIT_FAILED:
      return("ERR_INIT_FAILED: Failed to initialize structure passed as an argument");
   case ERR_OPENING_FILE:
      return("ERR_OPENING_FILE: Could not open requested file");
   case ERR_CLOSING_FILE:
      return("ERR_CLOSING_FILE: Could not close requested file");
   case ERR_READING_FILE:
      return("ERR_READING_FILE: Error occured while reading file");
   case ERR_CREATING_DATABASE:
      return("ERR_CREATING_DATABASE: Error occured while creating database");
   case ERR_READING_DATABASE:
      return("ERR_READING_DATABASE: Error occured while reading database");
   case ERR_WRITING_DATABASE:
      return("ERR_WRITING_DATABASE: Error occured while writing database");
   case ERR_WRITING_FILE:
      return("ERR_WRITING_FILE: Error occured while writing file");
   case ERR_STRING_TOO_LONG:
      return("ERR_STRING_TOO_LONG: String encountered in file, structure, or as an argument was longer than expected.  Possibly caused by an uninitialed pointer, corrupt file or database");
   case ERR_TOO_MANY_FILES:
      return("ERR_TOO_MANY_FILES: The toolkit has reached its maximum open file limit of 252 files.");
   case N_ERRORS:
      return("N_ERRORS: More errors were reported then could be recorded.");
   }

   return("Unknown error code was encountered");
}




      

