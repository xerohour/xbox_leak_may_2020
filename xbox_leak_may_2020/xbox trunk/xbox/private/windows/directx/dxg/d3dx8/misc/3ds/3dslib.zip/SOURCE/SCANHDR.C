/****************************************************************************
 *
 *  SCANHDR.C
 *
 *  (C) Copyright 1997 by Autodesk, Inc.
 *
 *  This program is copyrighted by Autodesk, Inc. and is licensed to you under
 *  the following conditions.  You may not distribute or publish the source
 *  code of this program in any form.  You may incorporate this code in object
 *  form in derivative works provided such derivative works are (i.) are de-
 *  signed and intended to work solely with Autodesk, Inc. products, and (ii.)
 *  contain Autodesk's copyright notice "(C) Copyright 1995 by Autodesk, Inc."
 *
 *  AUTODESK PROVIDES THIS PROGRAM "AS IS" AND WITH ALL FAULTS.  AUTODESK SPE-
 *  CIFICALLY DISCLAIMS ANY IMPLIED WARRANTY OF MERCHANTABILITY OR FITNESS FOR
 *  A PARTICULAR USE.  AUTODESK, INC.  DOES NOT WARRANT THAT THE OPERATION OF
 *  THE PROGRAM WILL BE UNINTERRUPTED OR ERROR FREE.
 *
 ***************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "3dstype.h"
#include "3dsprim.h"
#include "smartall.h"

static void banner (char3ds *proc_name)
{
   char3ds *cp;
   long3ds i;
   
   static const long3ds banner_size = 10;
   static char3ds *banner_help[10] = 
   {
      "headtype:",
      "   -pub     = Only declarations marked public",
      "   -priv    = Only declarations marked private",
      "",
      "dectype:",
      "   -typedef = Only type definitions",
      "   -consts  = Only constants",
      "   -protos  = Only prototypes",
      "   -define  = Only #defines",
      "   -all     = All of the above"
   };

   cp = strrchr(proc_name, '\\');
   fprintf(stdout, "Usage: %s -[headtype] -[dectype] @<headerlist> <header> <header> ...\n", (cp) ? ++cp : proc_name);
   for(i = 0; i < banner_size; i++)

   {
      fprintf(stdout, "%s\n", banner_help[i]);
   }
}


/* Flags for things to scan */
ubyte3ds gettypedef;
ubyte3ds getconsts;
ubyte3ds getprots;
ubyte3ds getdefs;
ubyte3ds getpriv;
ubyte3ds getpub;

void scanfile(char3ds *fn)
{
   FILE *infile = NULL;
   byte3ds emitlines = False3ds;
   byte3ds emitplines = False3ds;
   char3ds *buffer;
   long3ds i;

   infile = fopen(fn, "r");
   if (infile == NULL) return;

   buffer = malloc(16000);
   if (buffer == NULL) return;
      
   while (fgets(buffer, 16000, infile))
   {

      for (i = 0; i < 1; i++)
      {
	 if (getpub)
	 {
	    if (gettypedef)
	       if (strncmp("/* Public Typedefs */", buffer, 16 ) == 0)
	       {emitlines = True3ds; break;}
	    if (getconsts)
	       if (strncmp("/* Public Consts */", buffer, 16) == 0)
	       {emitlines = True3ds; break;}
	    if (getprots)
	       if (strncmp("/* Public Prototypes */", buffer, 16) == 0)
	       {emitlines = True3ds; break;}
	    if (getdefs)
	       if (strncmp("/* Public Defines */", buffer, 16) == 0)
	       {emitlines = True3ds; break;}
	    if (strncmp("/* End Public */", buffer, 12) == 0)
	    {emitlines = False3ds; break;}
	 }
	 if (getpriv)
	 {
	    if (gettypedef)
	       if (strncmp("/* Private Typedefs */", buffer, 16) == 0)
	       {emitplines = True3ds; break;}
	    if (getconsts)
	       if (strncmp("/* Private Consts */", buffer, 16) == 0)
	       {emitplines = True3ds; break;}
	    if (getprots)
	       if (strncmp("/* Private Prototypes */", buffer, 16) == 0)
	       {emitplines = True3ds; break;}
	    if (getdefs)
	       if (strncmp("/* Private Defines */", buffer, 16) == 0)
	       {emitplines = True3ds; break;}
	    if (strncmp("/* End Private */", buffer, 12) == 0)
	    {emitplines = False3ds; break;}
	 }

	 if (emitlines)
	    fprintf(stdout, "%s", buffer);
	 if (emitplines)
	 {
	    if (buffer[0] == '\n' || buffer[0] == '\r')
	       fprintf(stdout, "%s", buffer);
	    else
	       fprintf(stdout, "/* Priv */ %s", buffer);
	 }
	 
      }
   }

   fclose(infile);

   free(buffer);
}

void main(int argc, char3ds *argv[])
{

   gettypedef = False3ds;
   getconsts = False3ds;
   getprots = False3ds;
   getdefs = False3ds;
   getpriv = False3ds;
   getpub = False3ds;

   if (argc > 1)
   {
      long3ds i;
            
      /* Scan for options and filenames */
      for (i = 1; i < argc; i++)
      {
	 switch(argv[i][0])
	 {
	 case '-': /* "-*" */
	    switch(argv[i][1])
	    {
	    case 'p': /* "-p*" */
	       switch(argv[i][2])
	       {
	       case 'u': /* "-pub" */
		  getpub = True3ds;
		  break;
	       case 'r': /* "-pr*" */
		  switch(argv[i][3])
		  {
		  case 'i':
		     getpriv = True3ds;
		     break;
		  case 'o':
		     getprots = True3ds;
		  }
		  break;
	       }
	       break;
	    case 't': /* '-t*' */
	       gettypedef = True3ds;
	       break;
	    case 'c':
	       getconsts = True3ds;
	       break;
	    case 'd':
	       getdefs = True3ds;
	       break;
	    case 'a':
	       gettypedef = getconsts = getprots = getdefs = True3ds;
	       break;
	    }
	    break;
	 case '@': /* list of files */
         {
	    char3ds *c;
	    char3ds *filename;
	    const char3ds *delimiters = " \r\n\t";
	    	    
	    FILE *f;
	    
	    c = argv[i]+1;
	    f = fopen(c, "r");
	    if (f == NULL) break;
	    filename = malloc(16000);
	    if (filename == NULL) break;

	    while(fgets(filename, 16000, f))
	    {
	       char *tok;
	       for(tok = strtok(filename, delimiters); tok != NULL; tok = strtok(NULL, delimiters))
	       {
		  /* scan the file */
		  scanfile(tok);
	       }
	    }

	    fclose(f);
	    break;
	 }
	    
	 default:
	    scanfile(argv[i]);
	    break;
	 }
      }

   } else
      banner(argv[0]);

   exit(0);
}

      
	      
	       
		   
		  
	 
	
     
   
   
